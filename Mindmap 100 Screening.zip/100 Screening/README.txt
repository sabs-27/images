GRADSTUDIO NOTES COMPLETE PORTABLE IMAGE FIX

START THE APP
1. Extract the complete ZIP.
2. Keep all files and folders together.
3. Double-click: Open GradStudio Notes.cmd
4. Do not open the HTML directly when using local images or disk note saving.
5. Node.js must be installed on Windows.

PORTABLE LOCAL IMAGE PATHS
The app no longer depends only on the original C:\Users\... location.

Supported examples:

!! C:\Users\sabar\OneDrive\Desktop\SQL MINDMAP 2\photo.avif
!! C:\Users\sabar\OneDrive\Desktop\sandbox\SQL MINDMAP 2\photo.avif
!! images\photo.avif
!! images\sql\photo.png

When the pasted absolute path still exists, the exact file is used.
When it no longer exists, the server searches the CURRENT app folder, which is
the folder containing the HTML, Server.cjs and launcher. It then remaps the old
path to the matching image inside the current project.

This means the complete project can move from:
C:\Users\sabar\OneDrive\Desktop\sandbox\SQL MINDMAP 2\

to:
D:\Study\SQL MINDMAP 2\

without editing the saved note, provided the image is still somewhere inside
the transferred project folder. The images folder is recommended.

If multiple project files have the same filename, use an images subfolder path
to identify the intended file.

FAST IMAGE SHORTCUT

!! https://example.com/photo.jpg

is treated as:

![Image](https://example.com/photo.jpg)

It also works with local paths:

!! images\photo.png
!! C:\Pictures\photo.jpg

Spaces after !! are optional. The shortcut is not transformed inside fenced
code blocks.

SUPPORTED LOCAL IMAGE EXTENSIONS
APNG, AVIF, BMP, CUR, DIB, GIF, HEIC, HEIF, ICO, JFIF, JPE, JPEG, JPG,
JXL, PJP, PJPEG, PNG, SVG, SVGZ, TIF, TIFF and WEBP.

The browser must also be able to decode the selected format. Current Chrome
normally supports JPG, PNG, GIF, WEBP, AVIF and SVG. HEIC, HEIF or JXL support
may vary.

IMAGE DISPLAY
- Consecutive images become a horizontal carousel.
- Tall portrait images use their natural aspect ratio and are not cropped.
- Landscape images are not stretched.
- Previous and next controls, keyboard navigation, touch swipe and trackpad
  scrolling remain available.

SAVING AND RECOVERY
- Save & Close waits for a verified disk write before closing.
- TXT, HTML, metadata and whole-app HTML writes are atomic and read back.
- Autosave and manual save requests are serialized.
- Browser emergency drafts survive reloads.
- A missing external TXT file does not delete a browser draft.
- Exact server errors and filenames are displayed and logged.
- Server errors are written to: GradStudio Notes error.log

MIND-MAP SEARCH
- Use the magnifying-glass button or Ctrl+F.
- Enter moves to the next result.
- Shift+Enter moves to the previous result.
- Matching collapsed branches are expanded.
- The selected node is centered and zoomed.
- The orange outline is measured from the visible number, title, icon and dot.

NOTE READING CONTROLS
- Global font size minus and plus buttons are beside Rename.
- Ctrl+wheel zoom changes gradually.
- Wide content has a thin horizontal scrollbar.
- Font size and layout preferences are remembered.

PACKAGE CONTENTS
GradStudio Notes.html
GradStudio Notes Server.cjs
Open GradStudio Notes.cmd
images\
htmls\
metadata\
notes-index.txt
README.txt
FEATURES.txt
VALIDATION.txt

RENAMING THE APP
The three main files may be renamed consistently:

SQL Notes.html
SQL Notes Server.cjs
Open SQL Notes.cmd

The launcher also works when the folder contains exactly one HTML file and one
CJS server file.
