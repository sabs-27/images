'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { fileURLToPath } = require('url');

const root = path.resolve(String(process.argv[2] || ''));
const port = Number(process.argv[3]);
const requestedMainHtml = path.basename(String(process.argv[4] || '').trim());
const selfDelete = process.argv.includes('--self-delete');
const metadataRoot = path.join(root, 'metadata');
const htmlNotesRoot = path.join(root, 'htmls');
const errorLogPath = path.join(root, 'GradStudio Notes error.log');
const textNotePattern = /^\d+(?:\.\d+)*\.N[1-9]\d*(?:[- _][a-z0-9][a-z0-9 _-]*)?\.txt$/i;
const htmlNotePattern = /^\d+(?:\.\d+)*\.N[1-9]\d*(?:[- _][a-z0-9][a-z0-9 _-]*)?\.html$/i;
const metadataPattern = /^\d+(?:\.\d+)*\.N[1-9]\d*(?:[- _][a-z0-9][a-z0-9 _-]*)?\.meta\.txt$/i;
const maximumRequestBytes = 100 * 1024 * 1024;

const imageMimeByExtension = Object.freeze({
    '.apng': 'image/apng', '.avif': 'image/avif', '.bmp': 'image/bmp',
    '.cur': 'image/x-icon', '.dib': 'image/bmp', '.gif': 'image/gif',
    '.heic': 'image/heic', '.heif': 'image/heif', '.ico': 'image/x-icon',
    '.jfif': 'image/jpeg', '.jpe': 'image/jpeg', '.jpeg': 'image/jpeg',
    '.jpg': 'image/jpeg', '.jxl': 'image/jxl', '.pjp': 'image/jpeg',
    '.pjpeg': 'image/jpeg', '.png': 'image/png', '.svg': 'image/svg+xml',
    '.svgz': 'image/svg+xml', '.tif': 'image/tiff', '.tiff': 'image/tiff',
    '.webp': 'image/webp'
});

if (!root || !Number.isInteger(port) || port < 1024 || port > 65535) process.exit(2);

function appendErrorLog(error, context = '') {
    try {
        const message = error && error.stack ? error.stack : String(error || 'Unknown error');
        fs.appendFileSync(errorLogPath, `[${new Date().toISOString()}] ${context}\n${message}\n\n`, 'utf8');
    } catch (_) {}
}

function isRootHtmlFileName(fileName) {
    return Boolean(fileName) && path.basename(fileName) === fileName && /\.html$/i.test(fileName);
}

function discoverMainHtmlFile() {
    const candidates = [];
    if (isRootHtmlFileName(requestedMainHtml)) candidates.push(requestedMainHtml);
    const serverStem = path.basename(__filename, path.extname(__filename)).replace(/\s+Server$/i, '').trim();
    if (serverStem) candidates.push(`${serverStem}.html`);

    for (const candidate of candidates) {
        const candidatePath = path.join(root, candidate);
        if (fs.existsSync(candidatePath) && fs.statSync(candidatePath).isFile()) return candidate;
    }

    const htmlFiles = fs.existsSync(root)
        ? fs.readdirSync(root, { withFileTypes: true })
            .filter(entry => entry.isFile() && /\.html$/i.test(entry.name) && !/\.backup-/i.test(entry.name))
            .map(entry => entry.name)
        : [];
    if (htmlFiles.length === 1) return htmlFiles[0];

    const mindMapFiles = htmlFiles.filter(fileName => {
        try {
            const sample = fs.readFileSync(path.join(root, fileName), 'utf8').slice(0, 1024 * 1024);
            return sample.includes('window.MINDMAP_ENTRY') && sample.includes('mindmap-js-engine');
        } catch (_) {
            return false;
        }
    });
    if (mindMapFiles.length === 1) return mindMapFiles[0];

    throw new Error(htmlFiles.length
        ? 'More than one HTML app exists in this folder. Rename the launcher to "Open <HTML filename>.cmd" or keep only one main HTML file.'
        : 'No main HTML app was found in the launcher folder.');
}

let htmlFileName;
let htmlPath;
try {
    htmlFileName = discoverMainHtmlFile();
    htmlPath = path.join(root, htmlFileName);
} catch (error) {
    appendErrorLog(error, 'Startup failed');
    console.error(error.message);
    process.exit(4);
}

function validBaseName(fileName, pattern) {
    return pattern.test(String(fileName || '')) && path.basename(fileName) === fileName;
}

function safePath(folder, fileName, pattern) {
    if (!validBaseName(fileName, pattern)) throw new Error(`Invalid note filename: ${fileName || '(empty)'}`);
    const resolvedFolder = path.resolve(folder);
    const resolved = path.resolve(resolvedFolder, fileName);
    if (!resolved.startsWith(resolvedFolder + path.sep)) throw new Error(`Invalid note path: ${fileName}`);
    return resolved;
}

function textNotePath(fileName) { return safePath(root, fileName, textNotePattern); }
function htmlNotePath(fileName) { return safePath(htmlNotesRoot, fileName, htmlNotePattern); }
function metadataPath(fileName) { return safePath(metadataRoot, fileName, metadataPattern); }

function listFiles(folder, pattern) {
    if (!fs.existsSync(folder)) return [];
    return fs.readdirSync(folder, { withFileTypes: true })
        .filter(entry => entry.isFile() && validBaseName(entry.name, pattern))
        .map(entry => entry.name)
        .sort((left, right) => left.localeCompare(right, undefined, { numeric: true, sensitivity: 'base' }));
}

function hashBuffer(buffer) {
    return crypto.createHash('sha256').update(buffer).digest('hex');
}

function atomicWriteVerified(target, content, encoding = 'utf8') {
    const folder = path.dirname(target);
    fs.mkdirSync(folder, { recursive: true });
    const data = Buffer.isBuffer(content) ? content : Buffer.from(String(content ?? ''), encoding);
    const temp = path.join(folder, `.${path.basename(target)}.${process.pid}.${Date.now()}.tmp`);
    const backup = path.join(folder, `.${path.basename(target)}.${process.pid}.${Date.now()}.bak`);
    let hadOriginal = false;

    try {
        fs.writeFileSync(temp, data);
        const tempReadback = fs.readFileSync(temp);
        if (!tempReadback.equals(data)) throw new Error(`Temporary write verification failed for ${path.basename(target)}.`);

        if (fs.existsSync(target)) {
            hadOriginal = true;
            fs.renameSync(target, backup);
        }
        fs.renameSync(temp, target);

        const finalReadback = fs.readFileSync(target);
        if (!finalReadback.equals(data)) throw new Error(`Final read-back verification failed for ${path.basename(target)}.`);
        if (hadOriginal && fs.existsSync(backup)) fs.unlinkSync(backup);
        return { bytes: data.length, sha256: hashBuffer(data) };
    } catch (error) {
        try { if (fs.existsSync(temp)) fs.unlinkSync(temp); } catch (_) {}
        try {
            if (hadOriginal && fs.existsSync(backup)) {
                if (fs.existsSync(target)) fs.unlinkSync(target);
                fs.renameSync(backup, target);
            }
        } catch (restoreError) {
            appendErrorLog(restoreError, `Backup restore failed for ${target}`);
        }
        throw error;
    }
}

function updateIndexes() {
    atomicWriteVerified(path.join(root, 'notes-index.txt'), `${listFiles(root, textNotePattern).join('\n')}\n`);
    atomicWriteVerified(path.join(htmlNotesRoot, 'html-index.txt'), `${listFiles(htmlNotesRoot, htmlNotePattern).join('\n')}\n`);
}

function send(response, statusCode, body, contentType = 'text/plain; charset=utf-8', extraHeaders = {}) {
    response.writeHead(statusCode, {
        'Content-Type': contentType,
        'Cache-Control': 'no-store',
        'X-Content-Type-Options': 'nosniff',
        ...extraHeaders
    });
    response.end(body);
}

function readBody(request) {
    return new Promise((resolve, reject) => {
        const chunks = [];
        let total = 0;
        request.on('data', chunk => {
            total += chunk.length;
            if (total > maximumRequestBytes) {
                reject(new Error('Save request is larger than 100 MB.'));
                request.destroy();
                return;
            }
            chunks.push(chunk);
        });
        request.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
        request.on('error', reject);
    });
}

function stripImageReferenceWrapping(value) {
    let clean = String(value || '').trim().replace(/^!!\s*/, '').trim();
    if (clean.length >= 2) {
        const first = clean[0];
        const last = clean[clean.length - 1];
        if ((first === '"' && last === '"') || (first === "'" && last === "'") || (first === '<' && last === '>')) {
            clean = clean.slice(1, -1).trim();
        }
    }
    return clean;
}

function normalizeRequestedImagePath(rawValue) {
    let requested = stripImageReferenceWrapping(rawValue);
    if (!requested) throw new Error('No local image path was provided.');
    try { requested = decodeURIComponent(requested); } catch (_) {}
    requested = stripImageReferenceWrapping(requested);
    if (/^https?:\/\//i.test(requested)) throw new Error('Internet image URLs must be loaded directly, not through the local-image route.');
    if (/^file:\/\//i.test(requested)) {
        try { requested = fileURLToPath(requested); }
        catch (_) { throw new Error('The pasted file URL is invalid.'); }
    }
    return requested;
}

function isAllowedImageFile(filePath) {
    return Boolean(imageMimeByExtension[path.extname(filePath).toLowerCase()]);
}

function collectProjectImages(folder, depth = 0, output = []) {
    if (depth > 12 || !fs.existsSync(folder)) return output;
    let entries = [];
    try { entries = fs.readdirSync(folder, { withFileTypes: true }); }
    catch (_) { return output; }

    for (const entry of entries) {
        if (entry.name === 'node_modules' || entry.name === '.git' || entry.name.startsWith('.')) continue;
        const full = path.join(folder, entry.name);
        if (entry.isDirectory()) collectProjectImages(full, depth + 1, output);
        else if (entry.isFile() && isAllowedImageFile(full)) output.push(full);
    }
    return output;
}

let imageIndexCache = { createdAt: 0, files: [] };
function projectImageFiles() {
    const now = Date.now();
    if (now - imageIndexCache.createdAt > 1500) {
        imageIndexCache = { createdAt: now, files: collectProjectImages(root) };
    }
    return imageIndexCache.files;
}

function splitPortableSegments(value) {
    return String(value || '')
        .replace(/^\\\\[^\\/]+[\\/]+/, '')
        .replace(/^[a-z]:[\\/]+/i, '')
        .replace(/\\/g, '/')
        .split('/')
        .map(segment => segment.trim())
        .filter(Boolean);
}

function suffixMatchScore(requestedSegments, relativeSegments) {
    let score = 0;
    let left = requestedSegments.length - 1;
    let right = relativeSegments.length - 1;
    while (left >= 0 && right >= 0 && requestedSegments[left].toLowerCase() === relativeSegments[right].toLowerCase()) {
        score += 1;
        left -= 1;
        right -= 1;
    }
    return score;
}

function resolvePortableLocalImage(rawValue) {
    const requested = normalizeRequestedImagePath(rawValue);
    const extension = path.extname(requested).toLowerCase();
    const contentType = imageMimeByExtension[extension];
    if (!contentType) throw new Error(`Unsupported local image extension: ${extension || '(none)'}`);

    const directCandidates = [];
    if (path.isAbsolute(requested)) directCandidates.push(path.normalize(requested));
    else directCandidates.push(path.resolve(root, requested.replace(/[\\/]+/g, path.sep)));

    for (const candidate of directCandidates) {
        try {
            if (fs.existsSync(candidate) && fs.statSync(candidate).isFile()) {
                return { target: candidate, contentType, remapped: false, requested };
            }
        } catch (_) {}
    }

    const requestedSegments = splitPortableSegments(requested);
    const requestedFileName = String(requestedSegments.at(-1) || '').toLowerCase();
    if (!requestedFileName) throw new Error(`Local image file not found: ${requested}`);

    const ranked = projectImageFiles()
        .filter(file => path.basename(file).toLowerCase() === requestedFileName)
        .map(file => {
            const relative = path.relative(root, file);
            const relativeSegments = splitPortableSegments(relative);
            return { file, relative, score: suffixMatchScore(requestedSegments, relativeSegments) };
        })
        .sort((a, b) => b.score - a.score || a.relative.length - b.relative.length || a.relative.localeCompare(b.relative));

    if (!ranked.length) {
        throw new Error(`Local image was not found. Pasted path: ${requested}. Put the image anywhere inside the current app folder, preferably in images\\.`);
    }
    const bestScore = ranked[0].score;
    const best = ranked.filter(item => item.score === bestScore);
    if (best.length > 1 && bestScore <= 1) {
        throw new Error(`More than one project image is named ${path.basename(requested)}. Use an images\\subfolder\\filename path to disambiguate it.`);
    }

    const target = ranked[0].file;
    const resolvedType = imageMimeByExtension[path.extname(target).toLowerCase()] || contentType;
    return { target, contentType: resolvedType, remapped: true, requested, relative: path.relative(root, target) };
}

function sendLocalImage(request, response, image) {
    const stats = fs.statSync(image.target);
    const headers = {
        'Content-Length': String(stats.size),
        'Cache-Control': 'private, max-age=60',
        'X-GradStudio-Image-Remapped': image.remapped ? 'true' : 'false',
        'X-GradStudio-Image-Path': encodeURIComponent(image.relative || image.target)
    };
    response.writeHead(200, {
        'Content-Type': image.contentType,
        'X-Content-Type-Options': 'nosniff',
        ...headers
    });
    if (request.method === 'HEAD') return response.end();
    const stream = fs.createReadStream(image.target);
    stream.on('error', error => {
        appendErrorLog(error, `Reading local image ${image.target}`);
        if (!response.headersSent) send(response, 500, 'Local image could not be read.');
        else response.destroy(error);
    });
    stream.pipe(response);
}

let idleTimer = null;
let shutdownTimer = null;
let server = null;
function stopServer() {
    if (!server) return;
    server.close(() => process.exit(0));
    const forceExit = setTimeout(() => process.exit(0), 2000);
    forceExit.unref();
}
function touchServer() {
    if (shutdownTimer) { clearTimeout(shutdownTimer); shutdownTimer = null; }
    if (idleTimer) clearTimeout(idleTimer);
    idleTimer = setTimeout(stopServer, 24 * 60 * 60 * 1000);
    idleTimer.unref();
}
function scheduleShutdown() {
    if (shutdownTimer) clearTimeout(shutdownTimer);
    shutdownTimer = setTimeout(stopServer, 4000);
    shutdownTimer.unref();
}

async function handleContentFile(request, response, requestUrl, kind) {
    const fileName = requestUrl.searchParams.get('name') || '';
    const isHtml = kind === 'html';
    const target = isHtml ? htmlNotePath(fileName) : textNotePath(fileName);
    if (request.method === 'GET') {
        if (!fs.existsSync(target)) return send(response, 404, `Note file not found: ${fileName}`);
        return send(response, 200, fs.readFileSync(target, 'utf8'), isHtml ? 'text/html; charset=utf-8' : 'text/plain; charset=utf-8');
    }
    if (request.method === 'PUT') {
        const content = await readBody(request);
        const verification = atomicWriteVerified(target, content, 'utf8');
        updateIndexes();
        return send(response, 200, JSON.stringify({
            saved: true, verified: true, fileName,
            folder: isHtml ? 'htmls' : '.',
            bytes: verification.bytes, sha256: verification.sha256
        }), 'application/json; charset=utf-8');
    }
    if (request.method === 'DELETE') {
        if (fs.existsSync(target)) fs.unlinkSync(target);
        updateIndexes();
        return send(response, 200, JSON.stringify({ deleted: true, fileName }), 'application/json; charset=utf-8');
    }
    return send(response, 405, 'Method not allowed.');
}

server = http.createServer(async (request, response) => {
    touchServer();
    const requestUrl = new URL(request.url, `http://127.0.0.1:${port}`);
    try {
        if (requestUrl.pathname === '/api/health' && request.method === 'GET') {
            return send(response, 200, JSON.stringify({
                service: 'gradstudio-notes', version: 9, mainHtml: htmlFileName,
                localImages: true, portableImageRemap: true, atomicSaves: true, verifiedSaves: true
            }), 'application/json; charset=utf-8');
        }
        if (requestUrl.pathname === '/api/local-image' && (request.method === 'GET' || request.method === 'HEAD')) {
            return sendLocalImage(request, response, resolvePortableLocalImage(requestUrl.searchParams.get('path')));
        }
        if (requestUrl.pathname === '/api/files' && request.method === 'GET') {
            return send(response, 200, JSON.stringify(listFiles(root, textNotePattern)), 'application/json; charset=utf-8');
        }
        if (requestUrl.pathname === '/api/html-files' && request.method === 'GET') {
            return send(response, 200, JSON.stringify(listFiles(htmlNotesRoot, htmlNotePattern)), 'application/json; charset=utf-8');
        }
        if (requestUrl.pathname === '/api/file') return await handleContentFile(request, response, requestUrl, 'text');
        if (requestUrl.pathname === '/api/html-file') return await handleContentFile(request, response, requestUrl, 'html');

        if (requestUrl.pathname === '/api/meta') {
            const fileName = requestUrl.searchParams.get('name') || '';
            const target = metadataPath(fileName);
            if (request.method === 'GET') {
                if (!fs.existsSync(target)) return send(response, 404, `Metadata file not found: ${fileName}`);
                return send(response, 200, fs.readFileSync(target, 'utf8'), 'application/json; charset=utf-8');
            }
            if (request.method === 'PUT') {
                const content = await readBody(request);
                JSON.parse(content || '{}');
                const verification = atomicWriteVerified(target, content, 'utf8');
                return send(response, 200, JSON.stringify({ saved: true, verified: true, fileName, ...verification }), 'application/json; charset=utf-8');
            }
            if (request.method === 'DELETE') {
                if (fs.existsSync(target)) fs.unlinkSync(target);
                return send(response, 200, JSON.stringify({ deleted: true, fileName }), 'application/json; charset=utf-8');
            }
        }

        if (requestUrl.pathname === '/api/html' && request.method === 'PUT') {
            const content = await readBody(request);
            if (!/^\s*<!doctype html>/i.test(content) || !content.includes('window.MINDMAP_ENTRY')) {
                throw new Error('Refusing to save an invalid mind-map HTML document.');
            }
            const verification = atomicWriteVerified(htmlPath, content, 'utf8');
            return send(response, 200, JSON.stringify({ saved: true, verified: true, fileName: htmlFileName, ...verification }), 'application/json; charset=utf-8');
        }

        if (requestUrl.pathname === '/api/shutdown' && request.method === 'POST') {
            send(response, 202, 'Stopping when the page remains closed.');
            scheduleShutdown();
            return;
        }
        if (requestUrl.pathname.startsWith('/api/')) return send(response, 404, 'Unknown notes API route.');

        if (request.method === 'GET' && requestUrl.pathname.startsWith('/htmls/')) {
            const fileName = decodeURIComponent(requestUrl.pathname.slice('/htmls/'.length));
            const target = htmlNotePath(fileName);
            if (!fs.existsSync(target) || !fs.statSync(target).isFile()) return send(response, 404, 'HTML note file not found.');
            return send(response, 200, fs.readFileSync(target), 'text/html; charset=utf-8');
        }

        const relativeName = requestUrl.pathname === '/' ? htmlFileName : decodeURIComponent(requestUrl.pathname).replace(/^\/+/, '');
        const target = path.resolve(root, relativeName);
        if (!target.startsWith(root + path.sep) || path.dirname(target) !== root || !fs.existsSync(target) || !fs.statSync(target).isFile()) {
            return send(response, 404, 'File not found.');
        }
        const extension = path.extname(target).toLowerCase();
        if (extension !== '.html' && extension !== '.txt') return send(response, 404, 'File not found.');
        return send(response, 200, fs.readFileSync(target), extension === '.html' ? 'text/html; charset=utf-8' : 'text/plain; charset=utf-8');
    } catch (error) {
        appendErrorLog(error, `${request.method} ${requestUrl.pathname}${requestUrl.search}`);
        const message = error && error.message ? error.message : 'Notes service request failed.';
        return send(response, 400, message);
    }
});

server.on('error', error => {
    appendErrorLog(error, 'Server error');
    process.exit(3);
});
server.listen(port, '127.0.0.1', () => {
    fs.mkdirSync(metadataRoot, { recursive: true });
    fs.mkdirSync(htmlNotesRoot, { recursive: true });
    fs.mkdirSync(path.join(root, 'images'), { recursive: true });
    updateIndexes();
    touchServer();
    if (selfDelete) setTimeout(() => fs.unlink(__filename, () => {}), 500).unref();
});
