@echo off
setlocal EnableExtensions EnableDelayedExpansion

for %%I in ("%~dp0.") do set "APP_ROOT=%%~fI"
set "APP_LAUNCHER_BASE=%~n0"
set "APP_BASE=!APP_LAUNCHER_BASE!"
if /I "!APP_BASE:~0,5!"=="Open " set "APP_BASE=!APP_BASE:~5!"
if not defined APP_BASE set "APP_BASE=Notes"
title !APP_BASE! Launcher

where node.exe >nul 2>nul
if errorlevel 1 (
  echo Node.js is required to run this local notes app.
  echo Install Node.js, then run this launcher again.
  pause
  exit /b 1
)

set "APP_HTML=%~dp0!APP_BASE!.html"
if not exist "!APP_HTML!" (
  set /a APP_HTML_COUNT=0
  set "APP_HTML_FOUND="
  for %%F in ("%~dp0*.html") do if exist "%%~fF" (
    set /a APP_HTML_COUNT+=1
    set "APP_HTML_FOUND=%%~fF"
  )
  if !APP_HTML_COUNT! EQU 1 set "APP_HTML=!APP_HTML_FOUND!"
)

if not exist "!APP_HTML!" (
  echo Could not identify the main HTML app.
  echo.
  echo Recommended matching names:
  echo   !APP_BASE!.html
  echo   !APP_BASE! Server.cjs
  echo   Open !APP_BASE!.cmd
  echo.
  echo A folder containing exactly one HTML file also works.
  pause
  exit /b 1
)

set "APP_SERVER=%~dp0!APP_BASE! Server.cjs"
if not exist "!APP_SERVER!" set "APP_SERVER=%~dp0!APP_BASE!.cjs"
if not exist "!APP_SERVER!" (
  set /a APP_SERVER_COUNT=0
  set "APP_SERVER_FOUND="
  for %%F in ("%~dp0*.cjs") do if exist "%%~fF" (
    set /a APP_SERVER_COUNT+=1
    set "APP_SERVER_FOUND=%%~fF"
  )
  if !APP_SERVER_COUNT! EQU 1 set "APP_SERVER=!APP_SERVER_FOUND!"
)

if not exist "!APP_SERVER!" (
  echo Could not identify the Node.js server file.
  echo.
  echo Recommended matching names:
  echo   !APP_BASE!.html
  echo   !APP_BASE! Server.cjs
  echo   Open !APP_BASE!.cmd
  echo.
  echo A folder containing exactly one CJS file also works.
  pause
  exit /b 1
)

for %%I in ("!APP_HTML!") do set "APP_HTML_NAME=%%~nxI"

for /f "usebackq delims=" %%P in (`powershell.exe -NoProfile -Command "$listener=[Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback,0); $listener.Start(); $port=$listener.LocalEndpoint.Port; $listener.Stop(); $port"`) do set "APP_PORT=%%P"
if not defined APP_PORT (
  echo Could not allocate a local port.
  pause
  exit /b 1
)

powershell.exe -NoProfile -WindowStyle Hidden -Command "$node=(Get-Command node.exe).Source; $q=[char]34; $args=$q+$env:APP_SERVER+$q+' '+$q+$env:APP_ROOT+$q+' '+$env:APP_PORT+' '+$q+$env:APP_HTML_NAME+$q; Start-Process -FilePath $node -ArgumentList $args -WindowStyle Hidden"

for /L %%I in (1,1,30) do (
  powershell.exe -NoProfile -Command "try { $response=Invoke-WebRequest -UseBasicParsing -TimeoutSec 1 -Uri ('http://127.0.0.1:'+$env:APP_PORT+'/api/health'); if ($response.StatusCode -eq 200) { exit 0 }; exit 1 } catch { exit 1 }"
  if not errorlevel 1 goto ready
  ping 127.0.0.1 -n 2 >nul
)

echo The local notes service did not start.
echo HTML: !APP_HTML!
echo Server: !APP_SERVER!
pause
exit /b 1

:ready
if /I "%APP_NO_BROWSER%"=="1" (
  echo http://127.0.0.1:!APP_PORT!/
  exit /b 0
)
start "" "http://127.0.0.1:!APP_PORT!/"
exit /b 0
