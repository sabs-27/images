let isCapturing = false;
let cancelActiveSeek = null;
let activeJob = null;

// Transcript caption-link sniffer.
// Runs a tiny page-world hook so we can capture the same signed YouTube
// `timedtext` URL that the player itself requests when captions are enabled.
const transcriptTimedTextLinks = new Map();
const TRANSCRIPT_SNIFFER_SOURCE = 'yt-screenshot-capture';

function getCurrentVideoId() {
  try {
    return new URL(location.href).searchParams.get('v') || '';
  } catch (_) {
    return '';
  }
}

function normalizeTimedTextUrl(rawUrl) {
  try {
    const url = new URL(String(rawUrl || ''), location.href);
    if (!url.href.includes('timedtext')) return '';
    // Keep the signed URL intact, but normalize away output-format overrides.
    url.searchParams.delete('fmt');
    return url.toString();
  } catch (_) {
    return '';
  }
}

window.addEventListener('message', (event) => {
  if (event.source !== window) return;
  if (!event.data || event.data.source !== TRANSCRIPT_SNIFFER_SOURCE) return;
  if (event.data.type !== 'timedtext-url') return;

  const cleanUrl = normalizeTimedTextUrl(event.data.url);
  if (!cleanUrl) return;

  try {
    const url = new URL(cleanUrl);
    const videoId = url.searchParams.get('v') || getCurrentVideoId();
    if (videoId) transcriptTimedTextLinks.set(videoId, cleanUrl);
  } catch (_) {}
});

(function injectTranscriptSniffer() {
  try {
    if (document.documentElement.dataset.ytScreenshotTranscriptSniffer === '1') return;
    document.documentElement.dataset.ytScreenshotTranscriptSniffer = '1';

    const script = document.createElement('script');
    script.src = chrome.runtime.getURL('subtitle-link-sniffer.js');
    script.async = false;
    script.onload = () => script.remove();
    script.onerror = () => script.remove();
    (document.head || document.documentElement).appendChild(script);
  } catch (_) {}
})();

function nextPaint() {
  return new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
}

function waitForSniffedTimedTextUrl(videoId, timeoutMs = 3000) {
  const existing = transcriptTimedTextLinks.get(videoId);
  if (existing) return Promise.resolve(existing);

  return new Promise((resolve) => {
    let finished = false;
    const finish = (value) => {
      if (finished) return;
      finished = true;
      window.removeEventListener('message', onMessage);
      clearTimeout(timer);
      resolve(value || transcriptTimedTextLinks.get(videoId) || '');
    };
    const onMessage = (event) => {
      if (event.source !== window) return;
      if (!event.data || event.data.source !== TRANSCRIPT_SNIFFER_SOURCE) return;
      if (event.data.type !== 'timedtext-url') return;
      const cleanUrl = normalizeTimedTextUrl(event.data.url);
      if (!cleanUrl) return;
      try {
        const u = new URL(cleanUrl);
        const eventVideoId = u.searchParams.get('v') || getCurrentVideoId();
        if (eventVideoId) transcriptTimedTextLinks.set(eventVideoId, cleanUrl);
        if (!videoId || eventVideoId === videoId) finish(cleanUrl);
      } catch (_) {}
    };
    window.addEventListener('message', onMessage);
    const timer = setTimeout(() => finish(''), timeoutMs);
  });
}

async function forceTimedTextRequest(videoId) {
  if (!videoId) return '';
  const cached = transcriptTimedTextLinks.get(videoId);
  if (cached) return cached;

  const button = document.querySelector('.ytp-subtitles-button');
  if (!button || button.disabled) return '';

  const wasEnabled = button.getAttribute('aria-pressed') === 'true';

  try {
    // Force one clean caption request while restoring the user's prior CC state.
    if (wasEnabled) {
      button.click();
      await nextPaint();
    }

    const waitPromise = waitForSniffedTimedTextUrl(videoId, 3500);
    button.click();
    const captured = await waitPromise;

    if (!wasEnabled && button.getAttribute('aria-pressed') === 'true') {
      button.click();
    } else if (wasEnabled && button.getAttribute('aria-pressed') !== 'true') {
      button.click();
    }

    return captured || transcriptTimedTextLinks.get(videoId) || '';
  } catch (_) {
    try {
      const currentlyEnabled = button.getAttribute('aria-pressed') === 'true';
      if (currentlyEnabled !== wasEnabled) button.click();
    } catch (_) {}
    return transcriptTimedTextLinks.get(videoId) || '';
  }
}

async function fetchCuesFromTimedTextUrl(baseUrl) {
  if (!baseUrl) return [];

  const attempts = [
    { fmt: null, parse: parseTimedTextXml },
    { fmt: 'srv3', parse: parseTimedTextXml },
    { fmt: 'vtt', parse: parseWebVtt },
    {
      fmt: 'json3',
      parse: (raw) => {
        const text = String(raw || '').trim();
        if (!text || !text.startsWith('{')) return [];
        try { return parseJson3Transcript(JSON.parse(text)); } catch (_) { return []; }
      }
    }
  ];

  for (const attempt of attempts) {
    try {
      const url = new URL(baseUrl);
      if (attempt.fmt) url.searchParams.set('fmt', attempt.fmt);
      else url.searchParams.delete('fmt');

      const response = await fetch(url.toString(), {
        credentials: 'include',
        cache: 'no-store'
      });
      if (!response.ok) continue;

      const raw = await response.text();
      if (!raw || !raw.trim()) continue;

      const cues = attempt.parse(raw);
      if (Array.isArray(cues) && cues.length > 0) return cues;
    } catch (_) {}
  }

  return [];
}

function cleanTranscriptCueText(value) {
  return normalizeTranscriptText(value)
    .replace(/\[.*?\]/g, '')
    .replace(/\s*>>\s*/g, ' ')
    .replace(/[♪━]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function mergeTranscriptCueText(previousText, nextText) {
  const left = String(previousText || '').trim();
  const right = String(nextText || '').trim();
  if (!left) return right;
  if (!right) return left;
  if (left === right) return left;
  if (left.endsWith(right)) return left;
  if (right.startsWith(left)) return right;

  const leftWords = left.split(/\s+/);
  const rightWords = right.split(/\s+/);
  const maxOverlap = Math.min(12, leftWords.length, rightWords.length);
  for (let size = maxOverlap; size >= 2; size--) {
    const a = leftWords.slice(-size).join(' ').toLowerCase();
    const b = rightWords.slice(0, size).join(' ').toLowerCase();
    if (a === b) {
      return `${leftWords.join(' ')} ${rightWords.slice(size).join(' ')}`.trim();
    }
  }
  return `${left} ${right}`.trim();
}

function groupTranscriptCues(cues, blockSize = 200) {
  const groups = [];
  let buffer = null;

  const ordered = (Array.isArray(cues) ? cues : [])
    .slice()
    .sort((a, b) => Number(a.start || 0) - Number(b.start || 0));

  for (const cue of ordered) {
    const cleanText = cleanTranscriptCueText(cue.text);
    if (!cleanText) continue;

    const start = Number(cue.start || 0);
    const end = Number.isFinite(Number(cue.end)) ? Number(cue.end) : start;

    if (!buffer) {
      buffer = { start, end, text: cleanText };
      continue;
    }

    const combined = mergeTranscriptCueText(buffer.text, cleanText);
    if (combined.length <= blockSize) {
      buffer.text = combined;
      buffer.end = Math.max(buffer.end, end);
    } else {
      groups.push(buffer);
      buffer = { start, end, text: cleanText };
    }
  }

  if (buffer) groups.push(buffer);
  return groups;
}


// Listen for messages from popup/background.
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'ping') {
    sendResponse({ ok: true });
    return true;
  }

  if (message.action === 'getVideoDuration') {
    const video = document.querySelector('video');
    sendResponse({ duration: video ? video.duration : 0 });
    return true;
  }

  if (message.action === 'getLocalCaptureState') {
    sendResponse({
      active: isCapturing,
      job: activeJob
    });
    return true;
  }

  if (message.action === 'startCaptureJob') {
    if (isCapturing) {
      sendResponse({ success: false, error: 'A capture is already running in this tab.' });
      return true;
    }

    const job = {
      startTime: message.startTime,
      endTime: message.endTime,
      interval: message.interval,
      quality: message.quality,
      videoDuration: message.videoDuration || 0,
      chapters: Array.isArray(message.chapters) ? message.chapters : [],
      timestampMode: message.timestampMode || null,
      timestampText: message.timestampText || ''
    };

    isCapturing = true;
    activeJob = {
      ...job,
      current: 0,
      total: calculateCaptureTotal(job),
      progress: 0
    };

    chrome.runtime.sendMessage({
      action: 'captureStarted',
      startTime: job.startTime,
      endTime: job.endTime,
      interval: job.interval,
      quality: job.quality,
      videoDuration: job.videoDuration,
      chapters: job.chapters,
      timestampMode: job.timestampMode,
      timestampText: job.timestampText,
      total: activeJob.total,
      progressText: job.timestampMode ? 'Processing timestamp chapters...' : 'Processing...'
    });

    // Acknowledge immediately so closing the popup cannot cancel the capture job.
    sendResponse({ success: true, started: true, total: activeJob.total });

    runCaptureJob(job).catch((error) => {
      console.error('Capture error:', error);
      const current = activeJob?.current || 0;
      const total = activeJob?.total || 0;
      isCapturing = false;
      activeJob = null;
      chrome.runtime.sendMessage({
        action: 'captureFinished',
        status: 'error',
        error: error.message,
        message: `Error: ${error.message}`,
        current,
        total
      });
    });

    return true;
  }

  if (message.action === 'stopCapture') {
    isCapturing = false;
    if (cancelActiveSeek) {
      cancelActiveSeek();
    }
    sendResponse({ success: true });
    return true;
  }
});

function calculateChunks(startTime, endTime) {
  const CHUNK_DURATION = 3600;
  const chunks = [];
  let chunkStart = startTime;

  while (chunkStart < endTime) {
    const chunkEnd = Math.min(chunkStart + CHUNK_DURATION, endTime);
    chunks.push({ start: chunkStart, end: chunkEnd });
    chunkStart = chunkEnd;
  }

  return chunks;
}

function countScreenshots(startTime, endTime, interval) {
  if (endTime <= startTime || interval <= 0) return 0;
  return Math.ceil((endTime - startTime) / interval);
}

function calculateJobTotal(startTime, endTime, interval) {
  return calculateChunks(startTime, endTime)
    .reduce((sum, chunk) => sum + countScreenshots(chunk.start, chunk.end, interval), 0);
}

function buildChapterRanges(chapters, startTime, endTime) {
  if (!Array.isArray(chapters) || chapters.length < 2) return [];

  const sorted = chapters
    .map(chapter => ({
      time: Number(chapter.time) || 0,
      title: String(chapter.title || '').trim() || 'Chapter',
      timestamp: String(chapter.timestamp || '')
    }))
    .sort((a, b) => a.time - b.time);

  const ranges = [];
  for (let index = 0; index < sorted.length - 1; index++) {
    const chapter = sorted[index];
    const nextTime = sorted[index + 1].time;
    const range = {
      ...chapter,
      start: Math.max(startTime, chapter.time),
      end: Math.min(endTime, nextTime)
    };
    if (range.end > range.start) ranges.push(range);
  }

  return ranges;
}

function calculateTimestampTotal(job) {
  return buildChapterRanges(job.chapters, job.startTime, job.endTime)
    .reduce((sum, chapter) => sum + calculateJobTotal(chapter.start, chapter.end, job.interval), 0);
}

function calculateCaptureTotal(job) {
  if (job.timestampMode && Array.isArray(job.chapters) && job.chapters.length > 0) {
    return calculateTimestampTotal(job);
  }
  return calculateJobTotal(job.startTime, job.endTime, job.interval);
}

async function runCaptureJob(job) {
  if (job.timestampMode && Array.isArray(job.chapters) && job.chapters.length > 0) {
    return runTimestampCaptureJob(job);
  }
  return runStandardCaptureJob(job);
}

async function runStandardCaptureJob(job) {
  const video = document.querySelector('video');
  if (!video) {
    throw new Error('Video element not found');
  }

  if (!video.videoWidth || !video.videoHeight) {
    await waitForVideoMetadata(video);
  }

  const chunks = calculateChunks(job.startTime, job.endTime);
  const totalScreenshots = calculateJobTotal(job.startTime, job.endTime, job.interval);
  const wasPlaying = !video.paused;
  const originalVolume = video.volume;
  let completedBeforeChunk = 0;

  chrome.runtime.sendMessage({
    action: 'updateProgress',
    progress: 0,
    current: 0,
    total: totalScreenshots,
    message: 'Loading YouTube transcript...'
  });

  // Normal (non-timestamp) capture also carries the complete video transcript.
  // Fetch it once and reuse it for every ZIP chunk.
  const fullVideoTranscript = await fetchYouTubeTranscript();

  if (wasPlaying) {
    video.pause();
  }
  video.volume = 0;

  try {
    for (let i = 0; i < chunks.length && isCapturing; i++) {
      const chunk = chunks[i];
      const chunkTotal = countScreenshots(chunk.start, chunk.end, job.interval);

      chrome.runtime.sendMessage({
        action: 'updateProgress',
        progress: totalScreenshots ? (completedBeforeChunk / totalScreenshots) * 100 : 0,
        current: completedBeforeChunk,
        total: totalScreenshots,
        message: chunks.length > 1
          ? `Processing chunk ${i + 1}/${chunks.length} (${formatTimestamp(chunk.start)} - ${formatTimestamp(chunk.end)})`
          : 'Processing...'
      });

      const screenshots = await captureChunkFrames(
        video,
        chunk.start,
        chunk.end,
        job.interval,
        job.quality,
        completedBeforeChunk,
        totalScreenshots
      );

      if (!isCapturing) break;

      if (screenshots.length > 0) {
        await createAndDownloadZip(
          screenshots,
          i + 1,
          chunks.length,
          chunk.start,
          chunk.end,
          fullVideoTranscript
        );
      }

      completedBeforeChunk += chunkTotal;
    }
  } finally {
    video.volume = originalVolume;
    if (wasPlaying && isCapturing) {
      video.play().catch(() => {});
    }
  }

  const current = activeJob?.current || completedBeforeChunk;

  if (!isCapturing) {
    activeJob = null;
    chrome.runtime.sendMessage({
      action: 'captureFinished',
      status: 'stopped',
      message: 'Stopped',
      current,
      total: totalScreenshots
    });
    return;
  }

  isCapturing = false;
  activeJob = null;
  chrome.runtime.sendMessage({
    action: 'captureFinished',
    status: 'completed',
    message: 'Complete! ZIP file downloaded.',
    current: totalScreenshots,
    total: totalScreenshots
  });
}


async function runTimestampCaptureJob(job) {
  const video = document.querySelector('video');
  if (!video) {
    throw new Error('Video element not found');
  }

  if (!video.videoWidth || !video.videoHeight) {
    await waitForVideoMetadata(video);
  }

  const chapters = buildChapterRanges(job.chapters, job.startTime, job.endTime);
  if (chapters.length === 0) {
    throw new Error('At least 2 timestamps are required to create a capture range.');
  }

  if (job.timestampMode === 'folders' && (job.endTime - job.startTime) > 3600) {
    throw new Error('One ZIP with folders is limited to a 1-hour pasted range. Use Separate ZIP per range for longer captures.');
  }

  const totalScreenshots = calculateTimestampTotal(job);
  const wasPlaying = !video.paused;
  const originalVolume = video.volume;
  let completedScreenshots = 0;
  const combinedFiles = [];

  chrome.runtime.sendMessage({
    action: 'updateProgress',
    progress: 0,
    current: 0,
    total: totalScreenshots,
    message: 'Loading YouTube transcript...'
  });

  // Fetch once for the whole video, then slice the transcript using the exact
  // same adjacent timestamp boundaries used for screenshot folders.
  const transcript = await fetchYouTubeTranscript();

  if (wasPlaying) {
    video.pause();
  }
  video.volume = 0;

  try {
    for (let chapterIndex = 0; chapterIndex < chapters.length && isCapturing; chapterIndex++) {
      const chapter = chapters[chapterIndex];
      const chapterChunks = calculateChunks(chapter.start, chapter.end);
      const chapterBaseName = getChapterBaseName(chapter);

      if (job.timestampMode === 'folders') {
        combinedFiles.push({
          name: `${chapterBaseName}/transcript.txt`,
          text: buildTranscriptText(chapter, chapter.start, chapter.end, transcript)
        });
      }

      for (let partIndex = 0; partIndex < chapterChunks.length && isCapturing; partIndex++) {
        const chunk = chapterChunks[partIndex];
        const chunkTotal = countScreenshots(chunk.start, chunk.end, job.interval);
        const partSuffix = chapterChunks.length > 1
          ? `, part ${partIndex + 1}/${chapterChunks.length}`
          : '';

        chrome.runtime.sendMessage({
          action: 'updateProgress',
          progress: totalScreenshots ? (completedScreenshots / totalScreenshots) * 100 : 0,
          current: completedScreenshots,
          total: totalScreenshots,
          message: `Range ${chapterIndex + 1}/${chapters.length}${partSuffix}: ${chapter.title}`
        });

        const screenshots = await captureChunkFrames(
          video,
          chunk.start,
          chunk.end,
          job.interval,
          job.quality,
          completedScreenshots,
          totalScreenshots
        );

        if (!isCapturing) break;

        if (screenshots.length > 0) {
          if (job.timestampMode === 'folders') {
            appendChapterFiles(combinedFiles, screenshots, chapterBaseName);
          } else {
            await createAndDownloadChapterZip(
              screenshots,
              chapter,
              partIndex + 1,
              chapterChunks.length,
              chunk.start,
              chunk.end,
              completedScreenshots + screenshots.length,
              totalScreenshots,
              transcript
            );
          }
        }

        completedScreenshots += chunkTotal;
      }
    }

    if (isCapturing && job.timestampMode === 'folders' && combinedFiles.length > 0) {
      await createAndDownloadCombinedTimestampZip(
        combinedFiles,
        completedScreenshots,
        totalScreenshots
      );
    }
  } finally {
    video.volume = originalVolume;
    if (wasPlaying && isCapturing) {
      video.play().catch(() => {});
    }
  }

  const current = activeJob?.current || completedScreenshots;

  if (!isCapturing) {
    activeJob = null;
    chrome.runtime.sendMessage({
      action: 'captureFinished',
      status: 'stopped',
      message: 'Stopped',
      current,
      total: totalScreenshots
    });
    return;
  }

  isCapturing = false;
  activeJob = null;
  chrome.runtime.sendMessage({
    action: 'captureFinished',
    status: 'completed',
    message: job.timestampMode === 'folders'
      ? 'Complete! ZIP downloaded with screenshot folders and timestamped transcripts.'
      : 'Complete! Range ZIP files downloaded with timestamped transcripts.',
    current: totalScreenshots,
    total: totalScreenshots
  });
}

async function waitForVideoMetadata(video) {
  if (video.videoWidth && video.videoHeight) return;

  await new Promise((resolve, reject) => {
    const onLoaded = () => {
      cleanup();
      resolve();
    };
    const onError = () => {
      cleanup();
      reject(new Error('Unable to load video metadata'));
    };
    const cleanup = () => {
      video.removeEventListener('loadedmetadata', onLoaded);
      video.removeEventListener('loadeddata', onLoaded);
      video.removeEventListener('error', onError);
    };

    video.addEventListener('loadedmetadata', onLoaded, { once: true });
    video.addEventListener('loadeddata', onLoaded, { once: true });
    video.addEventListener('error', onError, { once: true });
  });
}

// Event-driven seeking. There are no per-frame setTimeout delays here, so
// background/minimized tabs are not held up by Chrome timer throttling.
async function seekTo(video, targetTime) {
  if (!isCapturing) return false;

  const duration = Number.isFinite(video.duration) ? video.duration : targetTime;
  const safeTarget = Math.max(0, Math.min(targetTime, Math.max(0, duration - 0.001)));

  if (!video.seeking && video.readyState >= 2 && Math.abs(video.currentTime - safeTarget) < 0.05) {
    return true;
  }

  return await new Promise((resolve, reject) => {
    let settled = false;

    const cleanup = () => {
      video.removeEventListener('seeked', onReady);
      video.removeEventListener('loadeddata', onReady);
      video.removeEventListener('canplay', onReady);
      video.removeEventListener('error', onError);
      if (cancelActiveSeek === cancel) {
        cancelActiveSeek = null;
      }
    };

    const finish = (value) => {
      if (settled) return;
      settled = true;
      cleanup();
      resolve(value);
    };

    const onReady = () => {
      if (!isCapturing) {
        finish(false);
        return;
      }

      if (!video.seeking && video.readyState >= 2 && Math.abs(video.currentTime - safeTarget) < 0.6) {
        finish(true);
      }
    };

    const onError = () => {
      if (settled) return;
      settled = true;
      cleanup();
      reject(new Error(`Unable to seek video to ${formatTimestamp(targetTime)}`));
    };

    const cancel = () => finish(false);
    cancelActiveSeek = cancel;

    // Register listeners before changing currentTime so a fast seek cannot be missed.
    video.addEventListener('seeked', onReady);
    video.addEventListener('loadeddata', onReady);
    video.addEventListener('canplay', onReady);
    video.addEventListener('error', onError, { once: true });

    try {
      video.currentTime = safeTarget;
      queueMicrotask(onReady);
    } catch (error) {
      settled = true;
      cleanup();
      reject(error);
    }
  });
}

function canvasToJpegBlob(canvas, quality) {
  return new Promise((resolve, reject) => {
    canvas.toBlob((blob) => {
      if (blob) resolve(blob);
      else reject(new Error('Failed to encode screenshot'));
    }, 'image/jpeg', quality);
  });
}

async function captureChunkFrames(video, startTime, endTime, interval, quality, completedBeforeChunk, totalJobScreenshots) {
  const chunkTotal = countScreenshots(startTime, endTime, interval);
  const screenshots = new Array(chunkTotal);

  // Two canvases let JPEG encoding overlap the next video seek without reusing
  // a canvas before its previous toBlob() has finished.
  const slots = Array.from({ length: 2 }, () => {
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    return {
      canvas,
      ctx: canvas.getContext('2d'),
      pending: null
    };
  });

  let localIndex = 0;

  for (let time = startTime; time < endTime && isCapturing; time += interval) {
    const ready = await seekTo(video, time);
    if (!ready || !isCapturing) break;

    const slot = slots[localIndex % slots.length];

    // Only wait if this particular canvas is still encoding an older frame.
    if (slot.pending) {
      await slot.pending;
      slot.pending = null;
    }

    slot.ctx.drawImage(video, 0, 0, slot.canvas.width, slot.canvas.height);

    const screenshotIndex = localIndex;
    const captureTime = time;
    slot.pending = canvasToJpegBlob(slot.canvas, quality).then((blob) => {
      const timestamp = formatTimestamp(captureTime);
      screenshots[screenshotIndex] = {
        blob,
        filename: `screenshot_${timestamp}.jpg`,
        time: captureTime
      };
    });

    localIndex++;
    const globalCurrent = completedBeforeChunk + localIndex;
    const progress = totalJobScreenshots ? (globalCurrent / totalJobScreenshots) * 100 : 0;

    if (activeJob) {
      activeJob.current = globalCurrent;
      activeJob.total = totalJobScreenshots;
      activeJob.progress = progress;
    }

    chrome.runtime.sendMessage({
      action: 'updateProgress',
      progress,
      current: globalCurrent,
      total: totalJobScreenshots
    });
  }

  await Promise.all(slots.map(slot => slot.pending).filter(Boolean));
  return screenshots.filter(Boolean);
}

function formatTimestamp(seconds) {
  const hrs = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  
  if (hrs > 0) {
    return `${hrs}h${mins.toString().padStart(2, '0')}m${secs.toString().padStart(2, '0')}s`;
  }
  return `${mins}m${secs.toString().padStart(2, '0')}s`;
}

function getVideoTitle() {
  const selectors = [
    'ytd-watch-metadata h1 yt-formatted-string',
    '#title h1 yt-formatted-string',
    'h1.ytd-watch-metadata'
  ];

  for (const selector of selectors) {
    const element = document.querySelector(selector);
    const title = element?.textContent?.trim();
    if (title) return title;
  }

  const pageTitle = (document.title || '').replace(/\s*-\s*YouTube\s*$/i, '').trim();
  return pageTitle || 'YouTube Video';
}

function sanitizeFileName(value, fallback = 'YouTube Video') {
  let name = String(value || '')
    .replace(/[\u0000-\u001F\u007F]/g, '')
    .replace(/[\\/:*?"<>|]/g, ' - ')
    .replace(/\s+/g, ' ')
    .replace(/(?:\s+-\s+){2,}/g, ' - ')
    .trim()
    .replace(/[. ]+$/g, '');

  if (!name) name = fallback;

  // Windows reserved device names cannot be used as file/folder names.
  if (/^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\..*)?$/i.test(name)) {
    name = `_${name}`;
  }

  // Keep extracted paths comfortably below common Windows path-length limits.
  if (name.length > 120) {
    name = name.slice(0, 120).trim().replace(/[. ]+$/g, '');
  }

  return name || fallback;
}


function extractBalancedJsonArray(source, markerIndex) {
  const start = source.indexOf('[', markerIndex);
  if (start < 0) return null;

  let depth = 0;
  let inString = false;
  let escaped = false;

  for (let i = start; i < source.length; i++) {
    const ch = source[i];

    if (inString) {
      if (escaped) {
        escaped = false;
      } else if (ch === '\\') {
        escaped = true;
      } else if (ch === '"') {
        inString = false;
      }
      continue;
    }

    if (ch === '"') {
      inString = true;
      continue;
    }

    if (ch === '[') depth++;
    if (ch === ']') {
      depth--;
      if (depth === 0) return source.slice(start, i + 1);
    }
  }

  return null;
}

function decodeHtmlEntities(value) {
  // YouTube timed-text can contain HTML entities such as &#39;, &quot;, &amp;.
  // Decode them the same way dedicated subtitle tools do before any cleanup.
  const textArea = document.createElement('textarea');
  textArea.innerHTML = String(value || '');
  return textArea.value;
}

function normalizeTranscriptText(value) {
  return decodeHtmlEntities(value)
    .replace(/\u200b/g, '')
    .replace(/[\r\n]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function chooseCaptionTrack(tracks) {
  if (!Array.isArray(tracks) || tracks.length === 0) return null;

  const preferredLanguage = String(document.documentElement.lang || navigator.language || '')
    .toLowerCase()
    .split('-')[0];

  const sameLanguage = preferredLanguage
    ? tracks.filter(track => String(track.languageCode || '').toLowerCase().startsWith(preferredLanguage))
    : [];

  return sameLanguage.find(track => track.kind !== 'asr') ||
    sameLanguage[0] ||
    tracks.find(track => track.kind !== 'asr') ||
    tracks[0];
}

function getTrackDisplayName(track) {
  if (!track) return '';
  if (track.name?.simpleText) return track.name.simpleText;
  if (Array.isArray(track.name?.runs)) {
    return track.name.runs.map(run => run.text || '').join('').trim();
  }
  return track.languageCode || '';
}

function parseJson3Transcript(data) {
  const cues = [];
  for (const event of Array.isArray(data?.events) ? data.events : []) {
    if (!Array.isArray(event.segs) || event.segs.length === 0) continue;
    const text = normalizeTranscriptText(event.segs.map(seg => seg.utf8 || '').join(''));
    if (!text) continue;

    const start = Number(event.tStartMs || 0) / 1000;
    const duration = Math.max(0, Number(event.dDurationMs || 0) / 1000);
    const previous = cues[cues.length - 1];

    // YouTube auto-captions can occasionally emit the same event twice.
    if (previous && previous.text === text && Math.abs(previous.start - start) < 0.05) continue;

    cues.push({
      start,
      end: start + duration,
      text
    });
  }
  return cues;
}

function parseTimedTextXml(xmlText) {
  const text = String(xmlText || '').trim();
  if (!text) return [];

  const parser = new DOMParser();
  const doc = parser.parseFromString(text, 'text/xml');
  if (doc.querySelector('parsererror')) return [];

  const cues = [];

  // Classic timed-text format: <text start="12.3" dur="4.2">...</text>
  for (const node of Array.from(doc.querySelectorAll('text'))) {
    const cueText = normalizeTranscriptText(node.textContent || '');
    if (!cueText) continue;
    const start = Number(node.getAttribute('start') || 0);
    const duration = Number(node.getAttribute('dur') || 0);
    if (!Number.isFinite(start)) continue;
    cues.push({ start, end: start + Math.max(0, Number.isFinite(duration) ? duration : 0), text: cueText });
  }

  if (cues.length > 0) return cues;

  // srv3 format: <p t="12300" d="4200"><s>...</s></p>
  for (const node of Array.from(doc.querySelectorAll('p'))) {
    const cueText = normalizeTranscriptText(node.textContent || '');
    if (!cueText) continue;
    const startMs = Number(node.getAttribute('t') || 0);
    const durationMs = Number(node.getAttribute('d') || 0);
    if (!Number.isFinite(startMs)) continue;
    const start = startMs / 1000;
    const duration = Number.isFinite(durationMs) ? Math.max(0, durationMs / 1000) : 0;
    cues.push({ start, end: start + duration, text: cueText });
  }

  return cues;
}

function parseWebVtt(vttText) {
  const raw = String(vttText || '').replace(/\r/g, '').trim();
  if (!raw) return [];

  const cues = [];
  const blocks = raw.split(/\n\n+/);
  const toSeconds = (value) => {
    const clean = String(value || '').trim().replace(',', '.');
    const parts = clean.split(':').map(Number);
    if (parts.some(part => !Number.isFinite(part))) return NaN;
    if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
    if (parts.length === 2) return parts[0] * 60 + parts[1];
    return NaN;
  };

  for (const block of blocks) {
    const lines = block.split('\n').map(line => line.trim()).filter(Boolean);
    const timingIndex = lines.findIndex(line => line.includes('-->'));
    if (timingIndex < 0) continue;

    const timing = lines[timingIndex].split('-->');
    const start = toSeconds(timing[0]);
    const end = toSeconds((timing[1] || '').split(/\s+/)[0]);
    if (!Number.isFinite(start)) continue;

    const cueText = normalizeTranscriptText(
      lines.slice(timingIndex + 1).join(' ').replace(/<[^>]+>/g, '')
    );
    if (!cueText) continue;

    const previous = cues[cues.length - 1];
    if (previous && previous.text === cueText && Math.abs(previous.start - start) < 0.05) continue;
    cues.push({ start, end: Number.isFinite(end) ? end : start, text: cueText });
  }

  return cues;
}

function transcriptTimestampToSeconds(timestampText) {
  const clean = String(timestampText || '').trim();
  const parts = clean.split(':').map(value => Number(value.trim()));
  if (parts.some(value => !Number.isFinite(value))) return NaN;
  if (parts.length === 2) return parts[0] * 60 + parts[1];
  if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
  return NaN;
}

function parseVisibleTranscriptFromDom() {
  const cues = [];
  const selectors = [
    'ytd-transcript-segment-renderer',
    'ytd-transcript-segment-list-renderer ytd-transcript-segment-renderer'
  ];
  const segments = Array.from(document.querySelectorAll(selectors.join(',')));

  for (const segment of segments) {
    const timestampNode = segment.querySelector('.segment-timestamp, [class*="timestamp"]');
    const textNode = segment.querySelector('.segment-text, [class*="segment-text"]');
    const timestampText = timestampNode?.textContent?.trim() || '';
    const cueText = normalizeTranscriptText(textNode?.textContent || '');
    const start = transcriptTimestampToSeconds(timestampText);
    if (!Number.isFinite(start) || !cueText) continue;

    const previous = cues[cues.length - 1];
    if (previous && previous.text === cueText && Math.abs(previous.start - start) < 0.05) continue;
    cues.push({ start, end: start + 5, text: cueText });
  }

  return cues;
}

function waitForTranscriptSegments(timeoutMs = 7000) {
  const immediate = parseVisibleTranscriptFromDom();
  if (immediate.length > 0) return Promise.resolve(immediate);

  return new Promise((resolve) => {
    let done = false;
    let timer = null;
    const finish = (cues) => {
      if (done) return;
      done = true;
      observer.disconnect();
      if (timer) clearTimeout(timer);
      resolve(cues || []);
    };

    const observer = new MutationObserver(() => {
      const cues = parseVisibleTranscriptFromDom();
      if (cues.length > 0) finish(cues);
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
    timer = setTimeout(() => finish(parseVisibleTranscriptFromDom()), timeoutMs);
  });
}

function findTranscriptButton() {
  const candidates = Array.from(document.querySelectorAll(
    'button, tp-yt-paper-button, yt-button-shape button, ytd-button-renderer button, [role="button"]'
  ));

  return candidates.find((element) => {
    const aria = String(element.getAttribute('aria-label') || '').toLowerCase();
    const title = String(element.getAttribute('title') || '').toLowerCase();
    const text = normalizeTranscriptText(element.textContent || '').toLowerCase();
    const label = `${aria} ${title} ${text}`;
    return label.includes('show transcript') || label === 'transcript' || label.includes(' transcript');
  }) || null;
}

async function tryOpenTranscriptPanel() {
  const existing = parseVisibleTranscriptFromDom();
  if (existing.length > 0) return existing;

  // YouTube normally places Show transcript inside the expanded description.
  // Expand it if necessary, then search by accessible label/text instead of a
  // single brittle DOM selector.
  let transcriptButton = findTranscriptButton();
  if (!transcriptButton) {
    const expandButton = document.querySelector(
      '#description-inline-expander #expand, ytd-text-inline-expander #expand, tp-yt-paper-button#expand'
    );
    if (expandButton) {
      try { expandButton.click(); } catch (_) {}
      await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
      transcriptButton = findTranscriptButton();
    }
  }

  if (!transcriptButton) return [];

  try {
    transcriptButton.click();
  } catch (_) {
    return [];
  }

  return await waitForTranscriptSegments(7000);
}

function extractCaptionTracksFromHtml(html) {
  const source = String(html || '');
  const marker = '"captionTracks":';
  let markerIndex = source.indexOf(marker);

  while (markerIndex >= 0) {
    const arrayText = extractBalancedJsonArray(source, markerIndex + marker.length);
    if (arrayText) {
      try {
        const tracks = JSON.parse(arrayText);
        if (Array.isArray(tracks) && tracks.some(track => track?.baseUrl)) return tracks;
      } catch (_) {
        // Try the next occurrence instead of exposing a JSON parser error to the user.
      }
    }
    markerIndex = source.indexOf(marker, markerIndex + marker.length);
  }

  return [];
}

async function fetchCaptionTrackCues(track) {
  if (!track?.baseUrl) return [];

  const attempts = [
    { fmt: 'json3', parse: (text) => {
      const trimmed = String(text || '').trim();
      if (!trimmed || !trimmed.startsWith('{')) return [];
      try { return parseJson3Transcript(JSON.parse(trimmed)); } catch (_) { return []; }
    }},
    { fmt: 'vtt', parse: parseWebVtt },
    { fmt: 'srv3', parse: parseTimedTextXml },
    { fmt: null, parse: parseTimedTextXml }
  ];

  for (const attempt of attempts) {
    try {
      const url = new URL(track.baseUrl);
      if (attempt.fmt) url.searchParams.set('fmt', attempt.fmt);
      else url.searchParams.delete('fmt');

      const response = await fetch(url.toString(), {
        credentials: 'include',
        cache: 'no-store'
      });
      if (!response.ok) continue;

      const raw = await response.text();
      if (!raw || !raw.trim()) continue;
      const cues = attempt.parse(raw);
      if (Array.isArray(cues) && cues.length > 0) return cues;
    } catch (_) {
      // Continue to the next YouTube caption format.
    }
  }

  return [];
}

async function fetchYouTubeTranscript() {
  const videoId = getCurrentVideoId();

  // Primary path: mimic the reliable behavior of dedicated subtitle tools.
  // Capture the signed timed-text URL from the YouTube player itself, then
  // download the caption XML directly.
  if (videoId) {
    let timedTextUrl = transcriptTimedTextLinks.get(videoId) || '';
    if (!timedTextUrl) {
      timedTextUrl = await forceTimedTextRequest(videoId);
    }
    if (timedTextUrl) {
      const cues = await fetchCuesFromTimedTextUrl(timedTextUrl);
      if (cues.length > 0) {
        return {
          cues,
          language: '',
          trackName: 'YouTube captions',
          source: 'youtube-timedtext-sniffer',
          error: null
        };
      }
    }
  }

  // Fallback 1: transcript panel if YouTube already rendered it.
  let domCues = parseVisibleTranscriptFromDom();
  if (domCues.length > 0) {
    return {
      cues: domCues,
      language: '',
      trackName: 'YouTube transcript',
      source: 'youtube-transcript-panel',
      error: null
    };
  }

  // Fallback 2: signed caption tracks embedded in the player bootstrap data.
  let tracks = [];
  try {
    tracks = extractCaptionTracksFromHtml(document.documentElement.innerHTML);
  } catch (_) {}

  if (tracks.length === 0) {
    try {
      const watchResponse = await fetch(location.href, {
        credentials: 'include',
        cache: 'no-store'
      });
      if (watchResponse.ok) {
        tracks = extractCaptionTracksFromHtml(await watchResponse.text());
      }
    } catch (_) {}
  }

  if (tracks.length > 0) {
    const preferred = chooseCaptionTrack(tracks);
    const orderedTracks = [preferred, ...tracks.filter(track => track !== preferred)].filter(Boolean);

    for (const track of orderedTracks) {
      const cues = await fetchCaptionTrackCues(track);
      if (cues.length > 0) {
        return {
          cues,
          language: track.languageCode || '',
          trackName: getTrackDisplayName(track),
          source: 'youtube-captions',
          error: null
        };
      }
    }
  }

  // Final fallback: ask YouTube to render the transcript panel and scrape it.
  domCues = await tryOpenTranscriptPanel();
  if (domCues.length > 0) {
    return {
      cues: domCues,
      language: '',
      trackName: 'YouTube transcript',
      source: 'youtube-transcript-panel',
      error: null
    };
  }

  return {
    cues: [],
    language: '',
    trackName: '',
    source: 'unavailable',
    error: 'Transcript unavailable for this video.'
  };
}

function formatTranscriptTimestamp(seconds) {
  const value = Math.max(0, Math.floor(Number(seconds) || 0));
  const hrs = Math.floor(value / 3600);
  const mins = Math.floor((value % 3600) / 60);
  const secs = value % 60;
  return `${String(hrs).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

function buildTranscriptText(chapter, startTime, endTime, transcript) {
  const cues = Array.isArray(transcript?.cues)
    ? transcript.cues.filter(cue => cue.start >= startTime - 0.01 && cue.start < endTime)
    : [];

  if (cues.length === 0) {
    return `${transcript?.error || 'Transcript unavailable for this range.'}\n`;
  }

  // Dedicated subtitle tools do not print every raw cue timestamp. They merge
  // consecutive cues into readable blocks (about 200 characters by default)
  // and keep the timestamp of only the first cue in each block.
  const grouped = groupTranscriptCues(cues, 200);
  if (grouped.length === 0) {
    return 'Transcript unavailable for this range.\n';
  }

  return grouped
    .map(group => `[${formatTranscriptTimestamp(group.start)}] ${group.text}`)
    .join('\n\n') + '\n';
}

function buildFullTranscriptText(transcript) {
  const cues = Array.isArray(transcript?.cues) ? transcript.cues : [];

  if (cues.length === 0) {
    return `${transcript?.error || 'Transcript unavailable for this video.'}\n`;
  }

  const grouped = groupTranscriptCues(cues, 200);
  if (grouped.length === 0) {
    return 'Transcript unavailable for this video.\n';
  }

  return grouped
    .map(group => `[${formatTranscriptTimestamp(group.start)}] ${group.text}`)
    .join('\n\n') + '\n';
}

function formatChapterClock(seconds) {
  const hrs = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  return `${String(hrs).padStart(2, '0')}-${String(mins).padStart(2, '0')}-${String(secs).padStart(2, '0')}`;
}

function getChapterBaseName(chapter) {
  // The pasted title becomes the folder name. The timestamp is the range boundary,
  // not part of the folder name.
  return sanitizeFileName(chapter.title, `Chapter ${formatChapterClock(chapter.time)}`);
}

function appendChapterFiles(files, screenshots, chapterBaseName) {
  for (const screenshot of screenshots) {
    files.push({
      name: `${chapterBaseName}/${screenshot.filename}`,
      blob: screenshot.blob
    });
  }
}

function buildChapterInfoText(chapter, screenshots, startTime, endTime, partNum = 1, totalParts = 1) {
  return `YouTube Screenshot Capture - Timestamp Chapter\n\n` +
    `Video Title: ${getVideoTitle()}\n` +
    `Chapter: ${chapter.title}\n` +
    `Timestamp: ${formatChapterClock(chapter.time).replace(/-/g, ':')}\n` +
    `Capture Start: ${formatTimestamp(startTime)}\n` +
    `Capture End: ${formatTimestamp(endTime)}\n` +
    `Screenshots: ${screenshots.length}\n` +
    (totalParts > 1 ? `Part: ${partNum} of ${totalParts}\n` : '') +
    `Captured: ${new Date().toLocaleString()}\n\n` +
    `Screenshot List:\n${screenshots.map(s => `${s.filename} (${formatTimestamp(s.time)})`).join('\n')}\n`;
}

async function triggerZipDownload(zipBlob, filename) {
  const url = URL.createObjectURL(zipBlob);
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      action: 'downloadZip',
      url,
      filename
    }, (response) => {
      setTimeout(() => URL.revokeObjectURL(url), 10000);
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      if (!response?.success) {
        reject(new Error(response?.error || 'Download failed'));
        return;
      }
      resolve(response);
    });
  });
}

async function createAndDownloadChapterZip(screenshots, chapter, partNum, totalParts, startTime, endTime, current, total, transcript) {
  const chapterBaseName = getChapterBaseName(chapter);
  const files = screenshots.map(screenshot => ({
    name: `${chapterBaseName}/${screenshot.filename}`,
    blob: screenshot.blob
  }));

  files.push({
    name: `${chapterBaseName}/transcript.txt`,
    text: buildTranscriptText(chapter, startTime, endTime, transcript)
  });

  chrome.runtime.sendMessage({
    action: 'updateProgress',
    progress: total ? (current / total) * 100 : 0,
    current,
    total,
    message: `Creating ZIP: ${chapterBaseName}`
  });

  const zipBlob = await createZipBlob(files);
  const filename = totalParts > 1
    ? `${chapterBaseName} - part ${partNum} of ${totalParts}.zip`
    : `${chapterBaseName}.zip`;
  await triggerZipDownload(zipBlob, filename);
}

async function createAndDownloadCombinedTimestampZip(files, current, total) {
  const videoTitle = getVideoTitle();
  const safeVideoTitle = sanitizeFileName(videoTitle);

  chrome.runtime.sendMessage({
    action: 'updateProgress',
    progress: total ? (current / total) * 100 : 100,
    current,
    total,
    message: 'Creating timestamp chapter ZIP...'
  });

  const zipBlob = await createZipBlob(files);
  await triggerZipDownload(zipBlob, `${safeVideoTitle}.zip`);
}

async function createAndDownloadZip(screenshots, chunkNum, totalChunks, startTime, endTime, transcript) {
  try {
    console.log('Creating ZIP file with', screenshots.length, 'screenshots...');

    const videoTitle = getVideoTitle();
    const safeVideoTitle = sanitizeFileName(videoTitle);
    const folderName = safeVideoTitle;
    const files = [];

    for (let i = 0; i < screenshots.length; i++) {
      const screenshot = screenshots[i];
      files.push({
        name: `${folderName}/${screenshot.filename}`,
        blob: screenshot.blob
      });

      if (i % 10 === 0) {
        chrome.runtime.sendMessage({
          action: 'updateProgress',
          progress: 100,
          current: screenshots.length,
          total: screenshots.length,
          message: `Preparing ZIP... ${i}/${screenshots.length}`
        });
      }
    }

    // Always include the complete video transcript for normal capture.
    // It uses the same readable ~200-character grouping and first-cue timestamp style.
    files.push({
      name: `${folderName}/transcript.txt`,
      text: buildFullTranscriptText(transcript)
    });

    console.log('Generating ZIP blob...');
    const zipBlob = await createZipBlob(files);
    
    console.log('ZIP created successfully, size:', (zipBlob.size / 1024 / 1024).toFixed(2), 'MB');
    
    // Name the ZIP after the YouTube video. Long captures keep the title
    // and add a chunk suffix so each download remains unique.
    let filename;
    if (totalChunks > 1) {
      filename = `${safeVideoTitle} - chunk ${chunkNum} of ${totalChunks}.zip`;
    } else {
      filename = `${safeVideoTitle}.zip`;
    }
    
    // Use Chrome downloads API for reliable downloading
    const url = URL.createObjectURL(zipBlob);
    
    chrome.runtime.sendMessage({
      action: 'downloadZip',
      url: url,
      filename: filename
    }, (response) => {
      console.log('Download triggered:', response);
      // Clean up URL after a delay
      setTimeout(() => URL.revokeObjectURL(url), 10000);
    });
    
    console.log('Download initiated for:', filename);
    
  } catch (error) {
    console.error('Error creating ZIP:', error);
    alert('Error creating ZIP file: ' + error.message + '\n\nPlease try again with fewer screenshots or lower quality.');
  }
}

function createZipBlob(files) {
  const fileRecords = [];
  const encoder = new TextEncoder();
  let offset = 0;

  const addBytes = (list, bytes) => {
    list.push(bytes);
    offset += bytes.length;
  };

  const writeUint16 = (value) => {
    return new Uint8Array([value & 0xff, (value >> 8) & 0xff]);
  };

  const writeUint32 = (value) => {
    return new Uint8Array([
      value & 0xff,
      (value >> 8) & 0xff,
      (value >> 16) & 0xff,
      (value >> 24) & 0xff
    ]);
  };

  const crc32 = (data) => {
    let crc = -1;
    for (let i = 0; i < data.length; i++) {
      crc = (crc >>> 8) ^ CRC_TABLE[(crc ^ data[i]) & 0xff];
    }
    return (crc ^ -1) >>> 0;
  };

  const localParts = [];

  return (async () => {
    for (const file of files) {
      const nameBytes = encoder.encode(file.name);
      let dataBytes;

      if (file.blob) {
        const buffer = await file.blob.arrayBuffer();
        dataBytes = new Uint8Array(buffer);
      } else {
        dataBytes = encoder.encode(file.text || '');
      }

      const crc = crc32(dataBytes);
      const localHeaderOffset = offset;

      addBytes(localParts, writeUint32(0x04034b50));
      addBytes(localParts, writeUint16(20));
      addBytes(localParts, writeUint16(0));
      addBytes(localParts, writeUint16(0));
      addBytes(localParts, writeUint16(0));
      addBytes(localParts, writeUint16(0));
      addBytes(localParts, writeUint32(crc));
      addBytes(localParts, writeUint32(dataBytes.length));
      addBytes(localParts, writeUint32(dataBytes.length));
      addBytes(localParts, writeUint16(nameBytes.length));
      addBytes(localParts, writeUint16(0));
      addBytes(localParts, nameBytes);
      addBytes(localParts, dataBytes);

      fileRecords.push({
        nameBytes: nameBytes,
        crc: crc,
        size: dataBytes.length,
        offset: localHeaderOffset
      });
    }

    const centralParts = [];
    let centralSize = 0;
    const centralOffset = offset;

    const addCentral = (bytes) => {
      centralParts.push(bytes);
      centralSize += bytes.length;
    };

    for (const record of fileRecords) {
      addCentral(writeUint32(0x02014b50));
      addCentral(writeUint16(20));
      addCentral(writeUint16(20));
      addCentral(writeUint16(0));
      addCentral(writeUint16(0));
      addCentral(writeUint16(0));
      addCentral(writeUint16(0));
      addCentral(writeUint32(record.crc));
      addCentral(writeUint32(record.size));
      addCentral(writeUint32(record.size));
      addCentral(writeUint16(record.nameBytes.length));
      addCentral(writeUint16(0));
      addCentral(writeUint16(0));
      addCentral(writeUint16(0));
      addCentral(writeUint16(0));
      addCentral(writeUint32(0));
      addCentral(writeUint32(record.offset));
      addCentral(record.nameBytes);
    }

    const endParts = [];
    const addEnd = (bytes) => endParts.push(bytes);

    addEnd(writeUint32(0x06054b50));
    addEnd(writeUint16(0));
    addEnd(writeUint16(0));
    addEnd(writeUint16(fileRecords.length));
    addEnd(writeUint16(fileRecords.length));
    addEnd(writeUint32(centralSize));
    addEnd(writeUint32(centralOffset));
    addEnd(writeUint16(0));

    return new Blob([...localParts, ...centralParts, ...endParts], { type: 'application/zip' });
  })();
}

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) {
      c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
    }
    table[i] = c >>> 0;
  }
  return table;
})();

// --- Single Screenshot Button Logic ---

function createScreenshotButton() {
  const btn = document.createElement('button');
  btn.className = 'ytp-button ytp-screenshot-button';
  btn.title = 'Screenshot';
  btn.setAttribute('aria-label', 'Screenshot');
  btn.setAttribute('aria-keyshortcuts', 's');
  
  // Camera Icon SVG - cleaner path, standard YouTube size (box 36x36 usually, but paths often centered)
  // Using a more standard path without the fill background to match "outline" feel of other icons
  btn.innerHTML = `
    <svg height="100%" version="1.1" viewBox="0 0 36 36" width="100%">
      <use class="ytp-svg-shadow" xlink:href="#ytp-id-screenshot-icon"></use>
      <path class="ytp-svg-fill" d="M23.5,10h-2.2l-1.3-3H16l-1.3,3h-2.2c-1.7,0-3,1.3-3,3v11c0,1.7,1.3,3,3,3h11c1.7,0,3-1.3,3-3V13C26.5,11.3,25.2,10,23.5,10z M18,22c-2.8,0-5-2.2-5-5s2.2-5,5-5s5,2.2,5,5S20.8,22,18,22z M18,13.5c-1.9,0-3.5,1.6-3.5,3.5s1.6,3.5,3.5,3.5s3.5-1.6,3.5-3.5S19.9,13.5,18,13.5z" id="ytp-id-screenshot-icon"></path>
    </svg>
  `;

  // Removed vertical-align: top which was causing misalignment
  // Adjusted opacity to standard unhovered state (usually handled by ytp-button but ensuring defaults)
  // Added some padding correction if needed, but usually just removing separate align fixes it.
  btn.style.cssText = `
    fill: #fff; 
    vertical-align: top;
    margin-top: -2px; 
  `;

  btn.addEventListener('click', captureSingleScreenshot);
  
  return btn;
}

function injectScreenshotButton() {
  // Check if button already exists
  if (document.querySelector('.ytp-screenshot-button')) return;

  const rightControls = document.querySelector('.ytp-right-controls');
  if (rightControls) {
    const btn = createScreenshotButton();
    // Insert before the settings button or at the beginning of right controls
    // Usually settings button is a good landmark, or just prepend.
    // YouTube's right controls order: [Autoplay, Subtitles, Settings, Miniplayer, Theater, Fullscreen]
    // Let's insert it as the first item in right controls for visibility
    rightControls.prepend(btn);
    console.log('Screenshot button injected');
  }
}

async function captureSingleScreenshot() {
  try {
    const video = document.querySelector('video');
    if (!video) throw new Error('Video element not found');

    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    
    const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/jpeg', 0.95));
    if (!blob) throw new Error('Failed to create image blob');

    const url = URL.createObjectURL(blob);
    const timestamp = formatTimestamp(video.currentTime).replace(/:/g, '-'); // Safe filename
    const filename = `youtube_screenshot_${timestamp}.jpg`;

    // Send to background to download
    chrome.runtime.sendMessage({
      action: 'downloadFile',
      url: url,
      filename: filename
    }, (response) => {
        if (response && response.success) {
            // Success animation or feedback could go here
            console.log('Screenshot saved:', filename);
        } else {
            console.error('Failed to save screenshot:', response ? response.error : 'Unknown error');
        }
        // Revoke URL after a delay to ensure download starts
        setTimeout(() => URL.revokeObjectURL(url), 10000);
    });

  } catch (error) {
    console.error('Screenshot failed:', error);
    alert('Failed to take screenshot: ' + error.message);
  }
}

// Observer to handle navigation and dynamic loading
const observer = new MutationObserver((mutations) => {
  if (!document.querySelector('.ytp-screenshot-button')) {
    injectScreenshotButton();
  }
});

observer.observe(document.body, {
  childList: true,
  subtree: true
});

// Initial injection try
injectScreenshotButton();
