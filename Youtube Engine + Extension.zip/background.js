// Background service worker for the extension
// Handles downloads and keeps capture state alive when the popup is closed.

let captureState = null;
let progressWritesSincePersist = 0;

chrome.runtime.onInstalled.addListener(() => {
  console.log('YouTube Screenshot Capture Extension Installed');
  chrome.storage.session.remove('captureState').catch(() => {});
});

async function loadCaptureState() {
  if (captureState) return captureState;

  try {
    const stored = await chrome.storage.session.get('captureState');
    captureState = stored.captureState || null;
  } catch (error) {
    console.warn('Unable to read capture state:', error);
  }

  return captureState;
}

async function persistCaptureState(force = false) {
  if (!captureState) return;

  progressWritesSincePersist++;
  if (!force && progressWritesSincePersist < 10) return;

  progressWritesSincePersist = 0;
  try {
    await chrome.storage.session.set({ captureState });
  } catch (error) {
    console.warn('Unable to persist capture state:', error);
  }
}

function handleDownload(url, filename, sendResponse) {
  chrome.downloads.download({
    url,
    filename,
    saveAs: false
  }, (downloadId) => {
    if (chrome.runtime.lastError) {
      console.error('Download error:', chrome.runtime.lastError);
      sendResponse({ success: false, error: chrome.runtime.lastError.message });
    } else {
      console.log('Download started with ID:', downloadId);
      sendResponse({ success: true, downloadId });
    }
  });
  return true;
}

// Listen for messages from content script and popup.
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'captureStarted') {
    captureState = {
      active: true,
      tabId: sender.tab?.id ?? message.tabId ?? null,
      status: 'processing',
      statusText: 'Processing...',
      progressText: message.progressText || 'Processing...',
      progress: 0,
      current: 0,
      total: message.total || 0,
      startTime: message.startTime || 0,
      endTime: message.endTime || 0,
      interval: message.interval || 3,
      quality: message.quality || 0.9,
      videoDuration: message.videoDuration || 0,
      timestampMode: message.timestampMode || null,
      timestampText: message.timestampText || '',
      chapters: Array.isArray(message.chapters) ? message.chapters : [],
      startedAt: Date.now()
    };
    progressWritesSincePersist = 0;
    persistCaptureState(true);
    sendResponse({ success: true });
    return true;
  }

  if (message.action === 'updateProgress') {
    if (captureState) {
      captureState = {
        ...captureState,
        active: true,
        status: 'processing',
        statusText: 'Processing...',
        progress: Number.isFinite(message.progress) ? message.progress : captureState.progress,
        current: Number.isFinite(message.current) ? message.current : captureState.current,
        total: Number.isFinite(message.total) ? message.total : captureState.total,
        progressText: message.message || captureState.progressText
      };
      persistCaptureState(Boolean(message.message));
    }
    // Do not resend the message. The popup receives the content-script message directly.
    return false;
  }

  if (message.action === 'captureFinished') {
    const finishedStatus = message.status || 'completed';
    captureState = {
      ...(captureState || {}),
      active: false,
      status: finishedStatus,
      statusText:
        finishedStatus === 'completed' ? 'Completed! Check your Downloads folder.' :
        finishedStatus === 'stopped' ? 'Stopped' :
        'Error occurred',
      progressText:
        message.message ||
        (finishedStatus === 'completed' ? 'Complete! ZIP file downloaded.' :
         finishedStatus === 'stopped' ? 'Stopped' : 'Capture failed'),
      progress: finishedStatus === 'completed' ? 100 : (captureState?.progress || 0),
      current: Number.isFinite(message.current) ? message.current : (captureState?.current || 0),
      total: Number.isFinite(message.total) ? message.total : (captureState?.total || 0),
      error: message.error || null,
      finishedAt: Date.now()
    };
    progressWritesSincePersist = 0;
    persistCaptureState(true);
    return false;
  }

  if (message.action === 'getCaptureState') {
    loadCaptureState().then((state) => sendResponse({ state }));
    return true;
  }

  if (message.action === 'stopActiveCapture') {
    loadCaptureState().then((state) => {
      if (!state?.active || !state.tabId) {
        sendResponse({ success: false, error: 'No active capture' });
        return;
      }

      chrome.tabs.sendMessage(state.tabId, { action: 'stopCapture' }, (response) => {
        if (chrome.runtime.lastError) {
          captureState = {
            ...state,
            active: false,
            status: 'stopped',
            statusText: 'Stopped',
            progressText: 'Stopped'
          };
          persistCaptureState(true);
          sendResponse({ success: false, error: chrome.runtime.lastError.message });
          return;
        }
        sendResponse(response || { success: true });
      });
    });
    return true;
  }

  if (message.action === 'downloadZip' || message.action === 'downloadFile') {
    return handleDownload(message.url, message.filename, sendResponse);
  }

  return false;
});

// If the capture tab is closed, clear the active state instead of leaving a stale session.
chrome.tabs.onRemoved.addListener(async (tabId) => {
  const state = await loadCaptureState();
  if (state?.active && state.tabId === tabId) {
    captureState = {
      ...state,
      active: false,
      status: 'error',
      statusText: 'Capture tab closed',
      progressText: 'Capture stopped because the YouTube tab was closed.'
    };
    await persistCaptureState(true);
  }
});
