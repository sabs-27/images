(() => {
  if (window.__YT_SCREENSHOT_TRANSCRIPT_SNIFFER__) return;
  window.__YT_SCREENSHOT_TRANSCRIPT_SNIFFER__ = true;

  const SOURCE = 'yt-screenshot-capture';
  const isTimedText = (value) => {
    try {
      const url = typeof value === 'string' ? value : (value && value.url);
      return typeof url === 'string' && url.includes('timedtext');
    } catch (_) {
      return false;
    }
  };

  const report = (value) => {
    try {
      const url = typeof value === 'string' ? value : (value && value.url);
      if (!isTimedText(url)) return;
      window.postMessage({ source: SOURCE, type: 'timedtext-url', url }, '*');
    } catch (_) {}
  };

  const originalFetch = window.fetch;
  if (typeof originalFetch === 'function') {
    window.fetch = function (...args) {
      report(args[0]);
      return originalFetch.apply(this, args);
    };
  }

  const originalOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    report(url);
    return originalOpen.call(this, method, url, ...rest);
  };
})();
