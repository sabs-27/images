let isCapturing = false;
let selectedQuality = 0.9;
let captureTabId = null;
let timestampsEnabled = false;

async function ensureContentScript(tabId) {
  const ping = () => new Promise(resolve => {
    chrome.tabs.sendMessage(tabId, { action: 'ping' }, (response) => {
      if (chrome.runtime.lastError) {
        resolve(false);
        return;
      }
      resolve(Boolean(response && response.ok));
    });
  });

  if (await ping()) {
    return true;
  }

  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ['content.js']
    });
  } catch (error) {
    console.error('Inject content script failed:', error);
    return false;
  }

  return await ping();
}

async function getVideoDurationFromTab(tabId) {
  return new Promise(resolve => {
    chrome.tabs.sendMessage(tabId, { action: 'getVideoDuration' }, (response) => {
      if (chrome.runtime.lastError) {
        console.error('Duration message error:', chrome.runtime.lastError);
        resolve(0);
        return;
      }
      resolve(response && response.duration ? Math.floor(response.duration) : 0);
    });
  });
}

function getCaptureState() {
  return new Promise(resolve => {
    chrome.runtime.sendMessage({ action: 'getCaptureState' }, (response) => {
      if (chrome.runtime.lastError) {
        resolve(null);
        return;
      }
      resolve(response?.state || null);
    });
  });
}

// Time parsing helper
function parseTimeToSeconds(timeStr) {
  const parts = timeStr.trim().split(':').map(p => parseInt(p) || 0);

  if (parts.length === 2) {
    return parts[0] * 60 + parts[1];
  } else if (parts.length === 3) {
    return parts[0] * 3600 + parts[1] * 60 + parts[2];
  }

  return 0;
}

// Format seconds to readable time
function formatTime(seconds) {
  const hrs = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);

  if (hrs > 0) {
    return `${hrs}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

function calculateTotalScreenshots(startTime, endTime, interval) {
  if (endTime <= startTime || interval <= 0) return 0;

  const CHUNK_DURATION = 3600;
  let total = 0;
  let chunkStart = startTime;

  while (chunkStart < endTime) {
    const chunkEnd = Math.min(chunkStart + CHUNK_DURATION, endTime);
    total += Math.ceil((chunkEnd - chunkStart) / interval);
    chunkStart = chunkEnd;
  }

  return total;
}


function formatChapterTimestamp(seconds) {
  const hrs = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  return `${String(hrs).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

function parseTimestampInput(text) {
  const chapters = [];
  const invalidLines = [];
  const seen = new Set();

  String(text || '').split(/\r?\n/).forEach((rawLine, index) => {
    let line = rawLine.trim();
    if (!line) return;

    // Also accept timestamps copied as YouTube/Markdown links:
    // [01:35:31](https://youtube...) Section title
    const linked = line.match(/^\[([0-9:]+)\]\([^)]+\)\s*(.*)$/);
    if (linked) line = `${linked[1]} ${linked[2]}`.trim();

    const match = line.match(/^(?:(\d+):)?(\d{1,2}):(\d{2})(?:\s+|\s*[-–—]\s*)(.*)$/);
    if (!match) {
      invalidLines.push(index + 1);
      return;
    }

    const hasHours = match[1] !== undefined;
    const hours = hasHours ? Number(match[1]) : 0;
    const minutes = Number(match[2]);
    const seconds = Number(match[3]);

    if (!Number.isFinite(hours) || !Number.isFinite(minutes) || !Number.isFinite(seconds) ||
        seconds > 59 || (hasHours && minutes > 59)) {
      invalidLines.push(index + 1);
      return;
    }

    const time = hasHours ? (hours * 3600 + minutes * 60 + seconds) : (minutes * 60 + seconds);
    if (seen.has(time)) {
      invalidLines.push(index + 1);
      return;
    }
    seen.add(time);

    chapters.push({
      time,
      title: (match[4] || '').trim() || `Chapter ${chapters.length + 1}`,
      timestamp: formatChapterTimestamp(time)
    });
  });

  chapters.sort((a, b) => a.time - b.time);
  return { chapters, invalidLines };
}

function getTimestampMode() {
  return document.querySelector('input[name="timestamp-output"]:checked')?.value || 'folders';
}

function getChapterRanges(chapters, startTime, endTime) {
  if (!Array.isArray(chapters) || chapters.length < 2 || endTime <= startTime) return [];

  const sorted = [...chapters].sort((a, b) => a.time - b.time);
  const ranges = [];

  // Each timestamp starts a range and the NEXT timestamp ends it.
  // Therefore N timestamps intentionally create N - 1 folders.
  for (let index = 0; index < sorted.length - 1; index++) {
    const chapter = sorted[index];
    const nextTime = sorted[index + 1].time;
    const range = {
      ...chapter,
      start: Math.max(startTime, chapter.time),
      end: Math.min(endTime, nextTime)
    };
    if (range.end > range.start) ranges.push(range);
  }

  return ranges;
}

function calculateTimestampScreenshots(chapters, startTime, endTime, interval) {
  return getChapterRanges(chapters, startTime, endTime)
    .reduce((sum, chapter) => sum + calculateTotalScreenshots(chapter.start, chapter.end, interval), 0);
}

function updateTimestampSummary() {
  const input = document.getElementById('timestamps-input');
  const summary = document.getElementById('timestamp-count');
  if (!input || !summary) return;

  const parsed = parseTimestampInput(input.value);
  const folderCount = Math.max(0, parsed.chapters.length - 1);
  if (parsed.invalidLines.length > 0) {
    summary.textContent = `${parsed.chapters.length} timestamps • ${folderCount} folder${folderCount === 1 ? '' : 's'} • check line${parsed.invalidLines.length > 1 ? 's' : ''} ${parsed.invalidLines.join(', ')}`;
  } else {
    summary.textContent = `${parsed.chapters.length} timestamp${parsed.chapters.length === 1 ? '' : 's'} • ${folderCount} folder${folderCount === 1 ? '' : 's'}`;
  }
}

function setTimestampUI(enabled) {
  timestampsEnabled = Boolean(enabled);
  const panel = document.getElementById('timestamp-panel');
  const button = document.getElementById('toggle-timestamps');
  if (!panel || !button) return;

  panel.style.display = timestampsEnabled ? 'block' : 'none';
  button.textContent = timestampsEnabled ? '− Remove Timestamps' : '+ Add Timestamps';
  button.classList.toggle('active', timestampsEnabled);
  updateTimestampSummary();
  updateEstimates();
}

// Update estimates
function updateEstimates() {
  const startTime = parseTimeToSeconds(document.getElementById('start-time').value);
  const endTime = parseTimeToSeconds(document.getElementById('end-time').value);
  const interval = parseInt(document.getElementById('interval').value) || 3;

  if (endTime <= startTime) {
    document.getElementById('estimated-count').textContent = '0';
    document.getElementById('estimated-size').textContent = '~0 MB';
    return;
  }

  let count = calculateTotalScreenshots(startTime, endTime, interval);
  if (timestampsEnabled) {
    const parsed = parseTimestampInput(document.getElementById('timestamps-input')?.value || '');
    if (parsed.chapters.length > 0) {
      count = calculateTimestampScreenshots(parsed.chapters, startTime, endTime, interval);
    }
  }
  const estimatedSizeMB = (count * 0.3 * selectedQuality).toFixed(1);

  document.getElementById('estimated-count').textContent = count;
  document.getElementById('estimated-size').textContent = `~${estimatedSizeMB} MB`;
}

function setQualityUI(quality) {
  selectedQuality = quality || 0.9;
  document.querySelectorAll('.quality-btn').forEach(btn => {
    const btnQuality = parseFloat(btn.dataset.quality);
    btn.classList.toggle('active', Math.abs(btnQuality - selectedQuality) < 0.01);
  });
}

function showYouTubeInterface() {
  document.getElementById('not-youtube').style.display = 'none';
  document.getElementById('youtube-interface').style.display = 'block';
}

function showNotYouTube() {
  document.getElementById('not-youtube').style.display = 'flex';
  document.getElementById('youtube-interface').style.display = 'none';
}

function updateProgressUI(message) {
  const percent = Math.max(0, Math.min(100, Math.round(message.progress || 0)));
  document.getElementById('progress-section').style.display = 'block';
  document.getElementById('progress-fill').style.width = `${percent}%`;
  document.getElementById('progress-percent').textContent = `${percent}%`;

  if (Number.isFinite(message.current)) {
    document.getElementById('current-screenshot').textContent = message.current;
  }
  if (Number.isFinite(message.total)) {
    document.getElementById('total-screenshots').textContent = message.total;
  }
  if (message.message) {
    document.getElementById('progress-text').textContent = message.message;
  }
}

function restoreActiveCapture(state) {
  isCapturing = true;
  captureTabId = state.tabId;
  selectedQuality = state.quality || 0.9;

  showYouTubeInterface();

  if (state.videoDuration > 0) {
    document.getElementById('video-duration').textContent = formatTime(state.videoDuration);
  }

  document.getElementById('start-time').value = formatTime(state.startTime || 0);
  document.getElementById('end-time').value = formatTime(state.endTime || 0);
  document.getElementById('interval').value = state.interval || 3;
  if (state.timestampText) {
    document.getElementById('timestamps-input').value = state.timestampText;
  }
  if (state.timestampMode) {
    const radio = document.querySelector(`input[name="timestamp-output"][value="${state.timestampMode}"]`);
    if (radio) radio.checked = true;
  }
  setTimestampUI(Boolean(state.timestampMode));
  setQualityUI(selectedQuality);
  updateEstimates();

  document.getElementById('start-capture').style.display = 'none';
  document.getElementById('stop-capture').style.display = 'flex';
  document.getElementById('progress-section').style.display = 'block';
  document.getElementById('status').textContent = state.statusText || 'Processing...';
  document.getElementById('status').className = 'value status-processing';
  document.getElementById('progress-text').textContent = state.progressText || 'Processing...';

  updateProgressUI({
    progress: state.progress || 0,
    current: state.current || 0,
    total: state.total || 0,
    message: state.progressText || 'Processing...'
  });
}

// Keep the original YouTube watch-page detection that worked in the uploaded extension.
async function checkYouTube() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  if (tab && tab.url && tab.url.includes('youtube.com/watch')) {
    showYouTubeInterface();

    const ready = await ensureContentScript(tab.id);
    if (!ready) {
      document.getElementById('status').textContent = 'Reload the page and try again';
      document.getElementById('status').className = 'value';
      return;
    }

    const duration = await getVideoDurationFromTab(tab.id);
    if (duration > 0) {
      document.getElementById('video-duration').textContent = formatTime(duration);
      document.getElementById('end-time').value = formatTime(duration);
      updateEstimates();
    }
  } else {
    showNotYouTube();
  }
}

// Initialize popup
document.addEventListener('DOMContentLoaded', async () => {
  document.querySelectorAll('.preset-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.getElementById('interval').value = btn.dataset.value;
      updateEstimates();
    });
  });

  document.querySelectorAll('.quality-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.quality-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      selectedQuality = parseFloat(btn.dataset.quality);
      updateEstimates();
    });
  });

  document.getElementById('start-time').addEventListener('input', updateEstimates);
  document.getElementById('end-time').addEventListener('input', updateEstimates);
  document.getElementById('interval').addEventListener('input', updateEstimates);
  document.getElementById('toggle-timestamps').addEventListener('click', () => setTimestampUI(!timestampsEnabled));
  document.getElementById('timestamps-input').addEventListener('input', () => {
    updateTimestampSummary();
    updateEstimates();
  });
  document.querySelectorAll('input[name="timestamp-output"]').forEach(radio => {
    radio.addEventListener('change', updateEstimates);
  });
  document.getElementById('start-capture').addEventListener('click', startCapture);
  document.getElementById('stop-capture').addEventListener('click', stopCapture);

  chrome.runtime.onMessage.addListener((message) => {
    if (message.action === 'updateProgress' && isCapturing) {
      updateProgressUI(message);
      return;
    }

    if (message.action === 'captureFinished') {
      isCapturing = false;
      captureTabId = null;
      showYouTubeInterface();

      document.getElementById('start-capture').style.display = 'flex';
      document.getElementById('stop-capture').style.display = 'none';

      if (message.status === 'completed') {
        document.getElementById('status').textContent = 'Completed! Check your Downloads folder.';
        document.getElementById('status').className = 'value status-completed';
        updateProgressUI({
          progress: 100,
          current: message.current,
          total: message.total,
          message: message.message || 'Complete! ZIP file downloaded.'
        });
      } else if (message.status === 'stopped') {
        document.getElementById('status').textContent = 'Stopped';
        document.getElementById('status').className = 'value';
        if (message.message) {
          document.getElementById('progress-text').textContent = message.message;
        }
      } else {
        document.getElementById('status').textContent = 'Error occurred';
        document.getElementById('status').className = 'value';
        document.getElementById('progress-text').textContent = message.message || `Error: ${message.error || 'Unknown error'}`;
      }
    }
  });

  const savedState = await getCaptureState();
  if (savedState?.active) {
    restoreActiveCapture(savedState);
  } else {
    await checkYouTube();
  }
});

async function startCapture() {
  let startTime = parseTimeToSeconds(document.getElementById('start-time').value);
  let endTime = parseTimeToSeconds(document.getElementById('end-time').value);
  const interval = parseInt(document.getElementById('interval').value) || 3;

  if (interval < 1) {
    alert('Interval must be at least 1 second!');
    return;
  }

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.id || !tab.url || !tab.url.includes('youtube.com/watch')) {
    alert('Please open a YouTube video and try again.');
    return;
  }

  const ready = await ensureContentScript(tab.id);
  if (!ready) {
    alert('Unable to connect to the YouTube page. Please reload the tab and try again.');
    return;
  }

  const duration = await getVideoDurationFromTab(tab.id);
  if (endTime <= 0 && duration > 0) {
    endTime = duration;
    document.getElementById('end-time').value = formatTime(duration);
  }

  if (endTime <= startTime && duration > startTime) {
    endTime = duration;
    document.getElementById('end-time').value = formatTime(duration);
  }

  if (endTime <= startTime) {
    alert('End time must be greater than start time!');
    return;
  }

  let chapters = [];
  let timestampMode = null;
  let timestampText = '';

  if (timestampsEnabled) {
    timestampText = document.getElementById('timestamps-input').value.trim();
    const parsed = parseTimestampInput(timestampText);

    if (!timestampText) {
      alert('Paste your timestamps first.');
      return;
    }
    if (parsed.invalidLines.length > 0) {
      alert(`Could not read timestamp line${parsed.invalidLines.length > 1 ? 's' : ''}: ${parsed.invalidLines.join(', ')}. Use formats like 00:02:09 Title or 2:09 Title.`);
      return;
    }

    chapters = parsed.chapters;
    if (chapters.length < 2) {
      alert('Paste at least 2 timestamps. The first starts the range and the next timestamp ends it.');
      return;
    }

    if (duration > 0 && chapters[chapters.length - 1].time > duration + 1) {
      alert('The last timestamp is beyond the end of this video.');
      return;
    }

    // Timestamp mode is driven by the pasted boundaries, not the manual Start/End fields.
    startTime = chapters[0].time;
    endTime = chapters[chapters.length - 1].time;
    document.getElementById('start-time').value = formatTime(startTime);
    document.getElementById('end-time').value = formatTime(endTime);

    const chapterRanges = getChapterRanges(chapters, startTime, endTime);
    if (chapterRanges.length === 0) {
      alert('The timestamps do not create a valid capture range.');
      return;
    }

    timestampMode = getTimestampMode();
    if (timestampMode === 'folders' && (endTime - startTime) > 3600) {
      alert('One ZIP with folders is limited to a 1-hour pasted range to avoid browser memory problems. For a longer range, choose “Separate ZIP per range”.');
      return;
    }
  }

  isCapturing = true;
  captureTabId = tab.id;

  document.getElementById('start-capture').style.display = 'none';
  document.getElementById('stop-capture').style.display = 'flex';
  document.getElementById('progress-section').style.display = 'block';
  document.getElementById('status').textContent = 'Processing...';
  document.getElementById('status').className = 'value status-processing';
  document.getElementById('progress-text').textContent = 'Processing...';

  const totalScreenshots = timestampMode
    ? calculateTimestampScreenshots(chapters, startTime, endTime, interval)
    : calculateTotalScreenshots(startTime, endTime, interval);
  const initialMessage = timestampMode ? `Processing timestamp chapters...` : 'Processing...';
  updateProgressUI({ progress: 0, current: 0, total: totalScreenshots, message: initialMessage });

  chrome.tabs.sendMessage(tab.id, {
    action: 'startCaptureJob',
    startTime,
    endTime,
    interval,
    quality: selectedQuality,
    videoDuration: duration,
    chapters,
    timestampMode,
    timestampText
  }, (response) => {
    if (chrome.runtime.lastError || !response?.success) {
      const errorMessage = chrome.runtime.lastError?.message || response?.error || 'Capture failed';
      console.error('Capture start failed:', errorMessage);
      isCapturing = false;
      captureTabId = null;
      document.getElementById('start-capture').style.display = 'flex';
      document.getElementById('stop-capture').style.display = 'none';
      document.getElementById('status').textContent = 'Error occurred';
      document.getElementById('status').className = 'value';
      document.getElementById('progress-text').textContent = `Error: ${errorMessage}`;
      alert(`Error during capture: ${errorMessage}`);
    }
  });
}

function stopCapture() {
  if (!isCapturing) return;

  chrome.runtime.sendMessage({ action: 'stopActiveCapture' }, () => {
    // The content script will send captureFinished; no active-tab dependency here.
  });

  isCapturing = false;
  captureTabId = null;
  document.getElementById('start-capture').style.display = 'flex';
  document.getElementById('stop-capture').style.display = 'none';
  document.getElementById('status').textContent = 'Stopped';
  document.getElementById('status').className = 'value';
  document.getElementById('progress-text').textContent = 'Stopped';
}
